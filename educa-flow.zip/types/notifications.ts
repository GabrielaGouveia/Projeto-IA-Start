export interface Comment {
  author: string
  text: string
  date: string
}

export interface NotificationType {
  id: string
  title: string
  message: string
  type: "alerta" | "comentario" | "avaliacao" | "geral"
  date: string
  read: boolean
  forwarded?: boolean
  comments?: Comment[]
  aluno?: {
    id: string
    nome: string
    turma: string
  }
}
