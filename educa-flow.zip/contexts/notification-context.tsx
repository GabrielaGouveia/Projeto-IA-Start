"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { NotificationType, Comment } from "@/types/notifications"

interface NotificationContextType {
  notifications: NotificationType[]
  addNotification: (notification: Omit<NotificationType, "id" | "date" | "read">) => void
  markAsRead: (id: string) => void
  addComment: (id: string, comment: string, author: string) => void
  forwardNotification: (id: string, comment: string) => void
  clearNotifications: () => void
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export function NotificationProvider({
  children,
  userType,
}: { children: React.ReactNode; userType: "professor" | "gerencia" | "parceiro" }) {
  const [notifications, setNotifications] = useState<NotificationType[]>([])

  // Carregar notificações do localStorage ao iniciar
  useEffect(() => {
    const storedNotifications = localStorage.getItem(`notifications_${userType}`)
    if (storedNotifications) {
      try {
        setNotifications(JSON.parse(storedNotifications))
      } catch (error) {
        console.error("Erro ao carregar notificações:", error)
      }
    } else {
      // Carregar notificações de exemplo para demonstração
      setNotifications(getExampleNotifications(userType))
    }
  }, [userType])

  // Salvar notificações no localStorage quando mudar
  useEffect(() => {
    if (notifications.length > 0) {
      localStorage.setItem(`notifications_${userType}`, JSON.stringify(notifications))
    }
  }, [notifications, userType])

  const addNotification = (notification: Omit<NotificationType, "id" | "date" | "read">) => {
    const newNotification: NotificationType = {
      ...notification,
      id: Date.now().toString(),
      date: new Date().toISOString(),
      read: false,
    }

    setNotifications((prev) => [newNotification, ...prev])
  }

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
    )
  }

  const addComment = (id: string, commentText: string, author: string) => {
    const comment: Comment = {
      author,
      text: commentText,
      date: new Date().toISOString(),
    }

    setNotifications((prev) =>
      prev.map((notification) =>
        notification.id === id
          ? {
              ...notification,
              comments: [...(notification.comments || []), comment],
            }
          : notification,
      ),
    )
  }

  const forwardNotification = (id: string, comment: string) => {
    // Marcar a notificação como encaminhada
    setNotifications((prev) =>
      prev.map((notification) =>
        notification.id === id
          ? {
              ...notification,
              forwarded: true,
              comments: [
                ...(notification.comments || []),
                {
                  author: "Professor",
                  text: `Encaminhado para gerência: ${comment}`,
                  date: new Date().toISOString(),
                },
              ],
            }
          : notification,
      ),
    )

    // Adicionar a notificação para a gerência
    const notification = notifications.find((n) => n.id === id)
    if (notification && userType === "professor") {
      // Simular o envio para a gerência
      const gerenciaNotifications = localStorage.getItem("notifications_gerencia")
      let gerenciaNotificationsList: NotificationType[] = []

      try {
        gerenciaNotificationsList = gerenciaNotifications ? JSON.parse(gerenciaNotifications) : []
      } catch (error) {
        console.error("Erro ao carregar notificações da gerência:", error)
      }

      const forwardedNotification: NotificationType = {
        id: Date.now().toString(),
        title: `Encaminhado: ${notification.title}`,
        message: notification.message,
        type: notification.type,
        date: new Date().toISOString(),
        read: false,
        aluno: notification.aluno,
        comments: [
          {
            author: "Professor",
            text: comment,
            date: new Date().toISOString(),
          },
        ],
      }

      gerenciaNotificationsList = [forwardedNotification, ...gerenciaNotificationsList]
      localStorage.setItem("notifications_gerencia", JSON.stringify(gerenciaNotificationsList))
    }
  }

  const clearNotifications = () => {
    setNotifications([])
    localStorage.removeItem(`notifications_${userType}`)
  }

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        addNotification,
        markAsRead,
        addComment,
        forwardNotification,
        clearNotifications,
      }}
    >
      {children}
    </NotificationContext.Provider>
  )
}

export function useNotifications() {
  const context = useContext(NotificationContext)
  if (context === undefined) {
    throw new Error("useNotifications must be used within a NotificationProvider")
  }
  return context
}

// Função para gerar notificações de exemplo para cada tipo de usuário
function getExampleNotifications(userType: string): NotificationType[] {
  const now = new Date().toISOString()
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
  const twoDaysAgo = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()

  if (userType === "professor") {
    return [
      {
        id: "1",
        title: "Alerta de Evasão",
        message: "O aluno Pedro Costa está ausente há 3 aulas consecutivas.",
        type: "alerta",
        date: now,
        read: false,
        aluno: {
          id: "4",
          nome: "Pedro Costa",
          turma: "Mobile - Turma 2",
        },
      },
      {
        id: "2",
        title: "Alerta de Desempenho",
        message: "A aluna Juliana Lima não entregou o projeto final do módulo 2.",
        type: "alerta",
        date: yesterday,
        read: false,
        aluno: {
          id: "5",
          nome: "Juliana Lima",
          turma: "Mobile - Turma 2",
        },
      },
      {
        id: "3",
        title: "Alerta de Engajamento",
        message: "O aluno Carlos Oliveira apresentou baixo engajamento nas últimas aulas.",
        type: "alerta",
        date: twoDaysAgo,
        read: true,
        aluno: {
          id: "2",
          nome: "Carlos Oliveira",
          turma: "Desenvolvimento Web - Turma 4",
        },
        comments: [
          {
            author: "Professor",
            text: "Entrei em contato com o aluno. Ele informou que está com problemas pessoais.",
            date: twoDaysAgo,
          },
        ],
      },
    ]
  } else if (userType === "gerencia") {
    return [
      {
        id: "1",
        title: "Encaminhado: Alerta de Evasão",
        message: "O aluno Pedro Costa está ausente há 3 aulas consecutivas.",
        type: "alerta",
        date: yesterday,
        read: false,
        aluno: {
          id: "4",
          nome: "Pedro Costa",
          turma: "Mobile - Turma 2",
        },
        comments: [
          {
            author: "Professor",
            text: "Tentei contato por telefone e e-mail, mas não obtive resposta. Solicito intervenção da gerência.",
            date: yesterday,
          },
        ],
      },
      {
        id: "2",
        title: "Relatório Mensal Disponível",
        message: "O relatório mensal de desempenho das turmas está disponível para análise.",
        type: "geral",
        date: twoDaysAgo,
        read: true,
      },
    ]
  } else if (userType === "parceiro") {
    return [
      {
        id: "1",
        title: "Avaliação de Engajamento Concluída",
        message: "A avaliação de engajamento da turma 'Desenvolvimento Web - Turma 3' foi concluída.",
        type: "avaliacao",
        date: yesterday,
        read: false,
      },
      {
        id: "2",
        title: "Novo Talento Identificado",
        message: "Um aluno com alto potencial foi identificado na turma 'Mobile - Turma 2'.",
        type: "geral",
        date: twoDaysAgo,
        read: true,
      },
    ]
  }

  return []
}
