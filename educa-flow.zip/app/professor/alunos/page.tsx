import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle } from "lucide-react"
import Link from "next/link"

const alunos = [
  {
    id: "1",
    nome: "Ana Silva",
    turma: "Desenvolvimento Web - Turma 3",
    email: "ana.silva@exemplo.com",
    risco: "baixo",
  },
  {
    id: "2",
    nome: "Carlos Oliveira",
    turma: "Desenvolvimento Web - Turma 4",
    email: "carlos.oliveira@exemplo.com",
    risco: "médio",
  },
  {
    id: "3",
    nome: "Mariana Santos",
    turma: "Desenvolvimento Web - Turma 3",
    email: "mariana.santos@exemplo.com",
    risco: "baixo",
  },
  {
    id: "4",
    nome: "Pedro Costa",
    turma: "Mobile - Turma 2",
    email: "pedro.costa@exemplo.com",
    risco: "alto",
  },
  {
    id: "5",
    nome: "Juliana Lima",
    turma: "Mobile - Turma 2",
    email: "juliana.lima@exemplo.com",
    risco: "médio",
  },
]

export default function AlunosPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Lista de Alunos</h1>
          <p className="text-muted-foreground">Visualize e gerencie todos os seus alunos.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 flex-1">
          <Input placeholder="Buscar alunos..." />
        </div>
        <div className="grid gap-2 w-full md:w-[180px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Turma" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as Turmas</SelectItem>
              <SelectItem value="web3">Desenvolvimento Web - Turma 3</SelectItem>
              <SelectItem value="web4">Desenvolvimento Web - Turma 4</SelectItem>
              <SelectItem value="mobile2">Mobile - Turma 2</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2 w-full md:w-[180px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Risco" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Níveis</SelectItem>
              <SelectItem value="baixo">Baixo</SelectItem>
              <SelectItem value="médio">Médio</SelectItem>
              <SelectItem value="alto">Alto</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Turma</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Risco</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {alunos.map((aluno) => (
              <TableRow key={aluno.id}>
                <TableCell className="font-medium">
                  <div className="flex items-center gap-2">
                    {aluno.risco === "alto" && <AlertTriangle className="h-4 w-4 text-red-500" />}
                    {aluno.nome}
                  </div>
                </TableCell>
                <TableCell>{aluno.turma}</TableCell>
                <TableCell>{aluno.email}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      aluno.risco === "baixo" ? "outline" : aluno.risco === "médio" ? "secondary" : "destructive"
                    }
                  >
                    {aluno.risco}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Link href={`/professor/alunos/${aluno.id}/avaliar`}>
                      <Button variant="outline" size="sm">
                        Avaliar
                      </Button>
                    </Link>
                    <Link href={`/professor/alunos/${aluno.id}/feedback`}>
                      <Button variant="ghost" size="sm">
                        Feedback
                      </Button>
                    </Link>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
