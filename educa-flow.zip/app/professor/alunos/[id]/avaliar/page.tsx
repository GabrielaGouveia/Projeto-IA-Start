"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function AvaliarAlunoPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)

  // Simulando dados de um aluno específico
  const aluno = {
    id: params.id,
    nome: "Ana Silva",
    turma: "Desenvolvimento Web - Turma 3",
  }

  // Estado para os campos do formulário
  const [formData, setFormData] = useState({
    frequencia: 15,
    totalAulas: 20,
    notaProva1: 8.5,
    notaProva2: 7.0,
    notaTrabalho1: 9.0,
    notaTrabalho2: 8.0,
    participacaoAtiva: 4,
    proatividade: 3,
    colaboracao: 5,
    comunicacao: 4,
    resolucaoProblemas: 4,
    feedbackGeral: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSliderChange = (name: string, value: number[]) => {
    setFormData((prev) => ({ ...prev, [name]: value[0] }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulando envio do formulário
    setTimeout(() => {
      setIsLoading(false)
      alert("Avaliação salva com sucesso!")
      router.push("/professor/alunos")
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/professor/alunos">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Avaliação Completa do Aluno: {aluno.nome}</h1>
          <p className="text-muted-foreground">{aluno.turma}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Frequência</CardTitle>
              <CardDescription>Informe a frequência do aluno nas aulas</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="frequencia">Aulas Presentes</Label>
                  <Input
                    id="frequencia"
                    name="frequencia"
                    type="number"
                    min="0"
                    value={formData.frequencia}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="totalAulas">Total de Aulas</Label>
                  <Input
                    id="totalAulas"
                    name="totalAulas"
                    type="number"
                    min="0"
                    value={formData.totalAulas}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notas</CardTitle>
              <CardDescription>Informe as notas do aluno</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="notaProva1">Nota Prova 1</Label>
                  <Input
                    id="notaProva1"
                    name="notaProva1"
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={formData.notaProva1}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notaProva2">Nota Prova 2</Label>
                  <Input
                    id="notaProva2"
                    name="notaProva2"
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={formData.notaProva2}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notaTrabalho1">Nota Trabalho 1</Label>
                  <Input
                    id="notaTrabalho1"
                    name="notaTrabalho1"
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={formData.notaTrabalho1}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notaTrabalho2">Nota Trabalho 2</Label>
                  <Input
                    id="notaTrabalho2"
                    name="notaTrabalho2"
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={formData.notaTrabalho2}
                    onChange={handleChange}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Avaliação de Engajamento</CardTitle>
              <CardDescription>Avalie o engajamento do aluno em uma escala de 1 a 5</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="participacaoAtiva">Participação Ativa</Label>
                    <span className="text-sm">{formData.participacaoAtiva}/5</span>
                  </div>
                  <Slider
                    id="participacaoAtiva"
                    min={1}
                    max={5}
                    step={1}
                    value={[formData.participacaoAtiva]}
                    onValueChange={(value) => handleSliderChange("participacaoAtiva", value)}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="proatividade">Proatividade</Label>
                    <span className="text-sm">{formData.proatividade}/5</span>
                  </div>
                  <Slider
                    id="proatividade"
                    min={1}
                    max={5}
                    step={1}
                    value={[formData.proatividade]}
                    onValueChange={(value) => handleSliderChange("proatividade", value)}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="colaboracao">Colaboração</Label>
                    <span className="text-sm">{formData.colaboracao}/5</span>
                  </div>
                  <Slider
                    id="colaboracao"
                    min={1}
                    max={5}
                    step={1}
                    value={[formData.colaboracao]}
                    onValueChange={(value) => handleSliderChange("colaboracao", value)}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="comunicacao">Comunicação</Label>
                    <span className="text-sm">{formData.comunicacao}/5</span>
                  </div>
                  <Slider
                    id="comunicacao"
                    min={1}
                    max={5}
                    step={1}
                    value={[formData.comunicacao]}
                    onValueChange={(value) => handleSliderChange("comunicacao", value)}
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="resolucaoProblemas">Resolução de Problemas</Label>
                    <span className="text-sm">{formData.resolucaoProblemas}/5</span>
                  </div>
                  <Slider
                    id="resolucaoProblemas"
                    min={1}
                    max={5}
                    step={1}
                    value={[formData.resolucaoProblemas]}
                    onValueChange={(value) => handleSliderChange("resolucaoProblemas", value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Feedback Geral</CardTitle>
              <CardDescription>Forneça um feedback geral sobre o desempenho do aluno</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="feedbackGeral">Comentários</Label>
                <Textarea
                  id="feedbackGeral"
                  name="feedbackGeral"
                  placeholder="Digite seu feedback aqui..."
                  rows={5}
                  value={formData.feedbackGeral}
                  onChange={handleChange}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Salvando..." : "Salvar Avaliação"}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </form>
    </div>
  )
}
