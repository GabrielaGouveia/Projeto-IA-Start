"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ArrowLeft, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"

export default function FeedbackAlunoPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [comentario, setComentario] = useState("")

  // Simulando dados de um aluno específico
  const aluno = {
    id: params.id,
    nome: "Ana Silva",
    turma: "Desenvolvimento Web - Turma 3",
    alerta: {
      tipo: "Ausência",
      descricao: "Ausente por 3 aulas consecutivas",
      data: "10/09/2023",
      gravidade: "médio",
    },
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulando envio do formulário
    setTimeout(() => {
      setIsLoading(false)
      alert("Feedback enviado com sucesso!")
      router.push("/professor/alunos")
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/professor/alunos">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Feedback do Alerta: {aluno.nome}</h1>
          <p className="text-muted-foreground">{aluno.turma}</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Detalhes do Alerta</CardTitle>
          <CardDescription>Informações sobre o alerta gerado para este aluno</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle
                  className={`h-5 w-5 ${
                    aluno.alerta.gravidade === "alto"
                      ? "text-red-500"
                      : aluno.alerta.gravidade === "médio"
                        ? "text-amber-500"
                        : "text-blue-500"
                  }`}
                />
                <span className="font-medium">{aluno.alerta.tipo}</span>
              </div>
              <Badge
                variant={
                  aluno.alerta.gravidade === "baixo"
                    ? "outline"
                    : aluno.alerta.gravidade === "médio"
                      ? "secondary"
                      : "destructive"
                }
              >
                {aluno.alerta.gravidade}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">Data: {aluno.alerta.data}</p>
            <p>{aluno.alerta.descricao}</p>
          </div>
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Feedback do Professor</CardTitle>
            <CardDescription>Forneça um feedback sobre o alerta gerado</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="comentario">Comentário</Label>
              <Textarea
                id="comentario"
                placeholder="Digite seu feedback aqui..."
                rows={5}
                value={comentario}
                onChange={(e) => setComentario(e.target.value)}
                required
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Enviando..." : "Enviar Feedback"}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
