import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { AvaliacaoEngajamentoForm } from "@/components/professor/avaliacao-engajamento-form"

export default function TurmaDetalhesPage({ params }: { params: { id: string } }) {
  // Simulando dados de uma turma específica
  const turma = {
    id: params.id,
    nome: "Desenvolvimento Web - Turma 3",
    curso: "Desenvolvimento Web Full Stack",
    inicio: "01/02/2023",
    fim: "01/12/2023",
    alunos: [
      {
        id: "1",
        nome: "Ana Silva",
        email: "ana.silva@exemplo.com",
        risco: "baixo",
      },
      {
        id: "2",
        nome: "Carlos Oliveira",
        email: "carlos.oliveira@exemplo.com",
        risco: "médio",
      },
      {
        id: "3",
        nome: "Mariana Santos",
        email: "mariana.santos@exemplo.com",
        risco: "baixo",
      },
      {
        id: "4",
        nome: "Pedro Costa",
        email: "pedro.costa@exemplo.com",
        risco: "alto",
      },
      {
        id: "5",
        nome: "Juliana Lima",
        email: "juliana.lima@exemplo.com",
        risco: "médio",
      },
    ],
    cronograma: [
      {
        id: "1",
        data: "01/02/2023",
        titulo: "Introdução ao HTML e CSS",
        tipo: "Aula",
      },
      {
        id: "2",
        data: "08/02/2023",
        titulo: "JavaScript Básico",
        tipo: "Aula",
      },
      {
        id: "3",
        data: "15/02/2023",
        titulo: "Projeto: Landing Page",
        tipo: "Projeto",
      },
      {
        id: "4",
        data: "22/02/2023",
        titulo: "Avaliação Módulo 1",
        tipo: "Avaliação",
      },
      {
        id: "5",
        data: "01/03/2023",
        titulo: "Introdução ao React",
        tipo: "Aula",
      },
    ],
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/professor/turmas">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Detalhes da Turma: {turma.nome}</h1>
          <p className="text-muted-foreground">{turma.curso}</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Informações da Turma</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Data de Início</p>
              <p className="font-medium">{turma.inicio}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Data de Término</p>
              <p className="font-medium">{turma.fim}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total de Alunos</p>
              <p className="font-medium">{turma.alunos.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="alunos" className="space-y-4">
        <TabsList>
          <TabsTrigger value="alunos">Alunos</TabsTrigger>
          <TabsTrigger value="cronograma">Cronograma</TabsTrigger>
          <TabsTrigger value="engajamento">Avaliação de Engajamento</TabsTrigger>
        </TabsList>
        <TabsContent value="alunos" className="space-y-4">
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Risco</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {turma.alunos.map((aluno) => (
                  <TableRow key={aluno.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {aluno.risco === "alto" && <AlertTriangle className="h-4 w-4 text-red-500" />}
                        {aluno.nome}
                      </div>
                    </TableCell>
                    <TableCell>{aluno.email}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          aluno.risco === "baixo" ? "outline" : aluno.risco === "médio" ? "secondary" : "destructive"
                        }
                      >
                        {aluno.risco}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Link href={`/professor/alunos/${aluno.id}/avaliar`}>
                          <Button variant="outline" size="sm">
                            Avaliar
                          </Button>
                        </Link>
                        <Link href={`/professor/alunos/${aluno.id}/feedback`}>
                          <Button variant="ghost" size="sm">
                            Feedback
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        <TabsContent value="cronograma" className="space-y-4">
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Tipo</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {turma.cronograma.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.data}</TableCell>
                    <TableCell className="font-medium">{item.titulo}</TableCell>
                    <TableCell>
                      <Badge
                        variant={item.tipo === "Aula" ? "outline" : item.tipo === "Projeto" ? "secondary" : "default"}
                      >
                        {item.tipo}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        <TabsContent value="engajamento" className="space-y-4">
          <AvaliacaoEngajamentoForm />
        </TabsContent>
      </Tabs>
    </div>
  )
}
