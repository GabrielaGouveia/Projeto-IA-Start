import { redirect } from "next/navigation"

export default function ProfessorPage() {
  redirect("/professor/painel")
}
