import type React from "react"
import { SidebarProfessor } from "@/components/professor/sidebar-professor"
import { NotificationProvider } from "@/contexts/notification-context"
import { ProfessorHeader } from "@/components/professor/professor-header"

export default function ProfessorLayout({ children }: { children: React.ReactNode }) {
  return (
    <NotificationProvider userType="professor">
      <div className="flex min-h-screen bg-slate-100">
        <SidebarProfessor />
        <div className="flex-1 overflow-auto flex flex-col">
          <ProfessorHeader />
          <div className="container mx-auto p-4 md:p-6 flex-1">{children}</div>
        </div>
      </div>
    </NotificationProvider>
  )
}
