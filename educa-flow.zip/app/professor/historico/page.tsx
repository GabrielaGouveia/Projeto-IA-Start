import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

const alunos = [
  {
    id: "1",
    nome: "Ana Silva",
    turma: "Desenvolvimento Web - Turma 3",
    interacoes: 5,
  },
  {
    id: "2",
    nome: "Carlos Oliveira",
    turma: "Desenvolvimento Web - Turma 4",
    interacoes: 3,
  },
  {
    id: "3",
    nome: "Mariana Santos",
    turma: "Desenvolvimento Web - Turma 3",
    interacoes: 2,
  },
  {
    id: "4",
    nome: "Pedro Costa",
    turma: "Mobile - Turma 2",
    interacoes: 7,
  },
  {
    id: "5",
    nome: "Juliana Lima",
    turma: "Mobile - Turma 2",
    interacoes: 4,
  },
]

const historicoAluno = {
  id: "1",
  nome: "Ana Silva",
  turma: "Desenvolvimento Web - Turma 3",
  historico: [
    {
      id: "1",
      tipo: "Alerta",
      data: "10/09/2023",
      descricao: "Alerta gerado: Ausente por 3 aulas consecutivas",
      gravidade: "médio",
    },
    {
      id: "2",
      tipo: "Feedback",
      data: "12/09/2023",
      descricao:
        "Feedback enviado: Entrei em contato com a aluna que informou problemas de saúde. Irá retornar na próxima semana.",
    },
    {
      id: "3",
      tipo: "Avaliação",
      data: "15/08/2023",
      descricao: "Avaliação completa realizada",
    },
    {
      id: "4",
      tipo: "Feedback",
      data: "01/08/2023",
      descricao: "Feedback enviado: Excelente desempenho no projeto final do módulo 1.",
    },
    {
      id: "5",
      tipo: "Alerta",
      data: "25/07/2023",
      descricao: "Alerta gerado: Nota abaixo da média na avaliação do módulo 1",
      gravidade: "baixo",
    },
  ],
}

export default function HistoricoPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Histórico</h1>
          <p className="text-muted-foreground">Visualize o histórico de interações com seus alunos.</p>
        </div>
      </div>

      <Tabs defaultValue="alunos" className="space-y-4">
        <TabsList>
          <TabsTrigger value="alunos">Lista de Alunos</TabsTrigger>
          <TabsTrigger value="detalhes">Detalhes do Aluno</TabsTrigger>
        </TabsList>
        <TabsContent value="alunos" className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="grid gap-2 flex-1">
              <Input placeholder="Buscar alunos..." />
            </div>
            <div className="grid gap-2 w-full md:w-[180px]">
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Turma" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas as Turmas</SelectItem>
                  <SelectItem value="web3">Desenvolvimento Web - Turma 3</SelectItem>
                  <SelectItem value="web4">Desenvolvimento Web - Turma 4</SelectItem>
                  <SelectItem value="mobile2">Mobile - Turma 2</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Turma</TableHead>
                  <TableHead>Interações</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {alunos.map((aluno) => (
                  <TableRow key={aluno.id}>
                    <TableCell className="font-medium">{aluno.nome}</TableCell>
                    <TableCell>{aluno.turma}</TableCell>
                    <TableCell>{aluno.interacoes}</TableCell>
                    <TableCell className="text-right">
                      <Link href={`/professor/historico?aluno=${aluno.id}`}>
                        <Button variant="ghost" size="sm">
                          Ver histórico
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        <TabsContent value="detalhes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Histórico do Aluno: {historicoAluno.nome}</CardTitle>
              <CardDescription>{historicoAluno.turma}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {historicoAluno.historico.map((item) => (
                  <div key={item.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge
                        variant={
                          item.tipo === "Alerta"
                            ? item.gravidade === "alto"
                              ? "destructive"
                              : item.gravidade === "médio"
                                ? "secondary"
                                : "outline"
                            : item.tipo === "Feedback"
                              ? "default"
                              : "secondary"
                        }
                      >
                        {item.tipo}
                      </Badge>
                      <span className="text-sm text-muted-foreground">{item.data}</span>
                    </div>
                    <p>{item.descricao}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
