import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ClipboardList, FileText } from "lucide-react"
import Link from "next/link"

export default function FormulariosPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Formulários</h1>
        <p className="text-muted-foreground">Acesse os formulários disponíveis para avaliação e feedback dos alunos.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <ClipboardList className="h-6 w-6 text-[#2563EB]" />
              <CardTitle>Formulário de Avaliação Completa</CardTitle>
            </div>
            <CardDescription>
              Realize uma avaliação completa do aluno, incluindo notas, frequência e engajamento.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Este formulário permite avaliar o desempenho completo do aluno, incluindo métricas acadêmicas e
              comportamentais.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/professor/alunos" className="w-full">
              <Button className="w-full">Acessar Formulário</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <FileText className="h-6 w-6 text-[#2563EB]" />
              <CardTitle>Formulário de Feedback do Alerta</CardTitle>
            </div>
            <CardDescription>Forneça feedback para alertas gerados pelo sistema de monitoramento.</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Este formulário permite registrar suas observações e ações tomadas em resposta aos alertas de risco
              identificados pelo sistema.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/professor/alunos" className="w-full">
              <Button className="w-full">Acessar Formulário</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
