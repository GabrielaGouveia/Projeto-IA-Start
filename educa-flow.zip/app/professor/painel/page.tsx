import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, School, AlertTriangle } from "lucide-react"
import { AlunosEmRiscoChart } from "@/components/professor/alunos-em-risco-chart"
import { ProgressoTurmasChart } from "@/components/professor/progresso-turmas-chart"
import { AIAlertSimulator } from "@/components/professor/ai-alert-simulator"

export default function PainelProfessorPage() {
  // Dados simulados para os KPIs
  const kpis = {
    totalAlunos: 75,
    totalTurmas: 3,
    alunosEmAlerta: 8,
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Painel do Professor</h1>
        <p className="text-muted-foreground">
          Bem-vindo ao seu painel. Aqui você encontra uma visão geral das suas turmas e alunos.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Alunos</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.totalAlunos}</div>
            <p className="text-xs text-muted-foreground">Alunos sob sua responsabilidade</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Turmas</CardTitle>
            <School className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.totalTurmas}</div>
            <p className="text-xs text-muted-foreground">Turmas ativas no período</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alunos em Alerta</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{kpis.alunosEmAlerta}</div>
            <p className="text-xs text-muted-foreground">Necessitam de atenção imediata</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Alunos por Nível de Risco</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <AlunosEmRiscoChart />
          </CardContent>
        </Card>
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Progresso das Turmas</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <ProgressoTurmasChart />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Alunos que Necessitam de Atenção</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      <span className="font-medium">Pedro Costa</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">Mobile - Turma 2</p>
                    <p className="text-sm">Ausente por 3 aulas consecutivas</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      <span className="font-medium">Juliana Lima</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">Mobile - Turma 2</p>
                    <p className="text-sm">Não entregou projeto final do módulo 2</p>
                  </div>
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-amber-500" />
                      <span className="font-medium">Carlos Oliveira</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1">Desenvolvimento Web - Turma 4</p>
                    <p className="text-sm">Baixo desempenho nas últimas avaliações</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <AIAlertSimulator />
      </div>
    </div>
  )
}
