"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { GraduationCap } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function ProfessorLoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulando um login
    setTimeout(() => {
      setIsLoading(false)
      // Redirecionar para dashboard (implementação futura)
      alert("Login realizado com sucesso! Redirecionando para o dashboard.")
    }, 1500)
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 to-slate-800">
      <Navbar />
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <Card className="w-full max-w-md bg-slate-800 border-slate-700">
          <CardHeader className="space-y-1">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-[#1E3A8A]/20 flex items-center justify-center">
                <GraduationCap className="h-8 w-8 text-[#2563EB]" />
              </div>
            </div>
            <CardTitle className="text-2xl text-center text-white">Login Professor</CardTitle>
            <CardDescription className="text-center text-slate-300">
              Acesse sua conta para gerenciar suas turmas e alunos
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">
                  Email
                </Label>
                <Input
                  id="email"
                  placeholder="seu.email@exemplo.com"
                  required
                  type="email"
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-white">
                    Senha
                  </Label>
                  <Link href="#" className="text-sm text-[#2563EB] hover:underline">
                    Esqueceu a senha?
                  </Link>
                </div>
                <Input id="password" required type="password" className="bg-slate-700 border-slate-600 text-white" />
              </div>
              <Button type="submit" className="w-full bg-[#2563EB] hover:bg-[#1E40AF]" disabled={isLoading}>
                {isLoading ? "Entrando..." : "Entrar"}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Link href="/perfil" className="text-sm text-slate-300 hover:text-white">
              Voltar para seleção de perfil
            </Link>
          </CardFooter>
        </Card>
      </main>
      <Footer />
    </div>
  )
}
