import type React from "react"
import { SidebarParceiro } from "@/components/parceiro/sidebar-parceiro"
import { NotificationProvider } from "@/contexts/notification-context"
import { ParceiroHeader } from "@/components/parceiro/parceiro-header"

export default function ParceiroLayout({ children }: { children: React.ReactNode }) {
  return (
    <NotificationProvider userType="parceiro">
      <div className="flex min-h-screen bg-slate-100">
        <SidebarParceiro />
        <div className="flex-1 overflow-auto flex flex-col">
          <ParceiroHeader />
          <div className="container mx-auto p-4 md:p-6 flex-1">{children}</div>
        </div>
      </div>
    </NotificationProvider>
  )
}
