import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { EngajamentoRadarChart } from "@/components/parceiro/engajamento-radar-chart"
import { EngajamentoBarChart } from "@/components/parceiro/engajamento-bar-chart"

const alunos = [
  {
    id: "1",
    nome: "Ana Silva",
    turma: "Desenvolvimento Web - Turma 3",
    participacao: 4,
    proatividade: 3,
    colaboracao: 5,
    comunicacao: 4,
    resolucao: 4,
    comprometimento: 5,
    media: 4.2,
  },
  {
    id: "2",
    nome: "Carlos Oliveira",
    turma: "Desenvolvimento Web - Turma 4",
    participacao: 3,
    proatividade: 4,
    colaboracao: 4,
    comunicacao: 3,
    resolucao: 5,
    comprometimento: 4,
    media: 3.8,
  },
  {
    id: "3",
    nome: "Mariana Santos",
    turma: "Desenvolvimento Web - Turma 3",
    participacao: 5,
    proatividade: 4,
    colaboracao: 5,
    comunicacao: 4,
    resolucao: 4,
    comprometimento: 5,
    media: 4.5,
  },
  {
    id: "4",
    nome: "Pedro Costa",
    turma: "Mobile - Turma 2",
    participacao: 3,
    proatividade: 3,
    colaboracao: 4,
    comunicacao: 3,
    resolucao: 3,
    comprometimento: 4,
    media: 3.3,
  },
  {
    id: "5",
    nome: "Juliana Lima",
    turma: "Mobile - Turma 2",
    participacao: 4,
    proatividade: 5,
    colaboracao: 4,
    comunicacao: 5,
    resolucao: 4,
    comprometimento: 5,
    media: 4.5,
  },
]

export default function EngajamentoPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Avaliação de Engajamento</h1>
          <p className="text-muted-foreground">
            Visualize o engajamento dos alunos nas turmas parceiras através de tabelas e gráficos.
          </p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 w-full md:w-[250px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Selecione uma turma" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as Turmas</SelectItem>
              <SelectItem value="web3">Desenvolvimento Web - Turma 3</SelectItem>
              <SelectItem value="web4">Desenvolvimento Web - Turma 4</SelectItem>
              <SelectItem value="mobile2">Mobile - Turma 2</SelectItem>
              <SelectItem value="data1">Data Science - Turma 1</SelectItem>
              <SelectItem value="ux2">UX/UI - Turma 2</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="tabela" className="space-y-4">
        <TabsList>
          <TabsTrigger value="tabela">Tabela</TabsTrigger>
          <TabsTrigger value="graficos">Gráficos</TabsTrigger>
        </TabsList>
        <TabsContent value="tabela" className="space-y-4">
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Turma</TableHead>
                  <TableHead>Participação</TableHead>
                  <TableHead>Proatividade</TableHead>
                  <TableHead>Colaboração</TableHead>
                  <TableHead>Comunicação</TableHead>
                  <TableHead>Resolução</TableHead>
                  <TableHead>Comprometimento</TableHead>
                  <TableHead>Média</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {alunos.map((aluno) => (
                  <TableRow key={aluno.id}>
                    <TableCell className="font-medium">{aluno.nome}</TableCell>
                    <TableCell>{aluno.turma}</TableCell>
                    <TableCell>{aluno.participacao}</TableCell>
                    <TableCell>{aluno.proatividade}</TableCell>
                    <TableCell>{aluno.colaboracao}</TableCell>
                    <TableCell>{aluno.comunicacao}</TableCell>
                    <TableCell>{aluno.resolucao}</TableCell>
                    <TableCell>{aluno.comprometimento}</TableCell>
                    <TableCell className="font-medium">{aluno.media.toFixed(1)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
        <TabsContent value="graficos" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Engajamento por Habilidade</CardTitle>
              </CardHeader>
              <CardContent className="pl-2">
                <EngajamentoRadarChart />
              </CardContent>
            </Card>
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Média de Engajamento por Aluno</CardTitle>
              </CardHeader>
              <CardContent className="pl-2">
                <EngajamentoBarChart />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
