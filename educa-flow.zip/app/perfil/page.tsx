import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import Link from "next/link"
import { UserCog, GraduationCap, Building2 } from "lucide-react"

export default function PerfilPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-900 to-slate-800">
      <Navbar />
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-5xl mx-auto py-12">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-white mb-4">Selecione seu perfil de acesso</h1>
            <p className="text-slate-300 max-w-2xl mx-auto">
              Escolha o tipo de perfil que melhor se adequa à sua função para acessar os recursos específicos da
              plataforma Educa Flow.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Cartão de Gerência */}
            <Link href="/login/gerencia" className="block transition-transform hover:scale-105">
              <Card className="h-full bg-slate-800 border-slate-700 hover:border-[#2563EB] transition-colors">
                <CardHeader className="pb-2">
                  <div className="w-16 h-16 rounded-full bg-[#1E3A8A]/20 flex items-center justify-center mx-auto mb-4">
                    <UserCog className="h-8 w-8 text-[#2563EB]" />
                  </div>
                  <CardTitle className="text-xl text-white text-center">Gerência</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-300 text-center">
                    Acesso a relatórios completos, métricas de desempenho e ferramentas administrativas para gestão
                    educacional.
                  </CardDescription>
                </CardContent>
              </Card>
            </Link>

            {/* Cartão de Professor */}
            <Link href="/login/professor" className="block transition-transform hover:scale-105">
              <Card className="h-full bg-slate-800 border-slate-700 hover:border-[#2563EB] transition-colors">
                <CardHeader className="pb-2">
                  <div className="w-16 h-16 rounded-full bg-[#1E3A8A]/20 flex items-center justify-center mx-auto mb-4">
                    <GraduationCap className="h-8 w-8 text-[#2563EB]" />
                  </div>
                  <CardTitle className="text-xl text-white text-center">Professor</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-300 text-center">
                    Ferramentas para acompanhamento de alunos, feedback estruturado e recursos pedagógicos assistidos
                    por IA.
                  </CardDescription>
                </CardContent>
              </Card>
            </Link>

            {/* Cartão de Empresa Parceira */}
            <Link href="/login/parceiro" className="block transition-transform hover:scale-105">
              <Card className="h-full bg-slate-800 border-slate-700 hover:border-[#2563EB] transition-colors">
                <CardHeader className="pb-2">
                  <div className="w-16 h-16 rounded-full bg-[#1E3A8A]/20 flex items-center justify-center mx-auto mb-4">
                    <Building2 className="h-8 w-8 text-[#2563EB]" />
                  </div>
                  <CardTitle className="text-xl text-white text-center">Empresa Parceira</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-300 text-center">
                    Acesso a métricas de engajamento, identificação de talentos e oportunidades de colaboração
                    educacional.
                  </CardDescription>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
