import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle } from "lucide-react"
import Link from "next/link"

const alertas = [
  {
    id: "1",
    aluno: "Ana Silva",
    turma: "Desenvolvimento Web - Turma 3",
    tipo: "Ausência",
    descricao: "Ausente por 3 aulas consecutivas",
    data: "10/09/2023",
    gravidade: "médio",
  },
  {
    id: "2",
    aluno: "Carlos Oliveira",
    turma: "Data Science - Turma 1",
    tipo: "Atividade",
    descricao: "Não entregou projeto final do módulo 2",
    data: "25/08/2023",
    gravidade: "alto",
  },
  {
    id: "3",
    aluno: "Mariana Santos",
    turma: "UX/UI - Turma 2",
    tipo: "Engajamento",
    descricao: "Baixa participação nas últimas 2 semanas",
    data: "15/09/2023",
    gravidade: "baixo",
  },
  {
    id: "4",
    aluno: "Pedro Costa",
    turma: "DevOps - Turma 1",
    tipo: "Desempenho",
    descricao: "Notas abaixo da média nos últimos 3 módulos",
    data: "05/09/2023",
    gravidade: "alto",
  },
  {
    id: "5",
    aluno: "Juliana Lima",
    turma: "Mobile - Turma 4",
    tipo: "Ausência",
    descricao: "Ausente por 2 aulas consecutivas",
    data: "12/09/2023",
    gravidade: "médio",
  },
]

export default function AlertasPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Alertas de Risco</h1>
          <p className="text-muted-foreground">Monitore e gerencie alertas de risco de evasão.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 flex-1">
          <Input placeholder="Buscar alertas..." />
        </div>
        <div className="grid gap-2 w-full md:w-[180px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Turma" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas as Turmas</SelectItem>
              <SelectItem value="web">Desenvolvimento Web</SelectItem>
              <SelectItem value="data">Data Science</SelectItem>
              <SelectItem value="ux">UX/UI Design</SelectItem>
              <SelectItem value="devops">DevOps</SelectItem>
              <SelectItem value="mobile">Mobile</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2 w-full md:w-[180px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Gravidade" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas</SelectItem>
              <SelectItem value="baixo">Baixa</SelectItem>
              <SelectItem value="médio">Média</SelectItem>
              <SelectItem value="alto">Alta</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Aluno</TableHead>
              <TableHead>Turma</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Data</TableHead>
              <TableHead>Gravidade</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {alertas.map((alerta) => (
              <TableRow key={alerta.id}>
                <TableCell className="font-medium">{alerta.aluno}</TableCell>
                <TableCell>{alerta.turma}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <AlertTriangle
                      className={`h-4 w-4 ${
                        alerta.gravidade === "alto"
                          ? "text-red-500"
                          : alerta.gravidade === "médio"
                            ? "text-amber-500"
                            : "text-blue-500"
                      }`}
                    />
                    {alerta.tipo}
                  </div>
                </TableCell>
                <TableCell>{alerta.data}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      alerta.gravidade === "baixo"
                        ? "outline"
                        : alerta.gravidade === "médio"
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {alerta.gravidade}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Link href={`/dashboard/alunos/${alerta.id}`}>
                    <Button variant="ghost" size="sm">
                      Ver aluno
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
