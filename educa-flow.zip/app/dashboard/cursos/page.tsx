import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus } from "lucide-react"
import Link from "next/link"

const cursos = [
  {
    id: "1",
    nome: "Desenvolvimento Web Full Stack",
    duracao: "10 meses",
    turmas: 3,
    alunos: 78,
    status: "ativo",
  },
  {
    id: "2",
    nome: "Ciência de Dados",
    duracao: "10 meses",
    turmas: 1,
    alunos: 22,
    status: "ativo",
  },
  {
    id: "3",
    nome: "Design de Experiência do Usuário",
    duracao: "10 meses",
    turmas: 2,
    alunos: 35,
    status: "ativo",
  },
  {
    id: "4",
    nome: "DevOps & Cloud",
    duracao: "10 meses",
    turmas: 1,
    alunos: 15,
    status: "ativo",
  },
  {
    id: "5",
    nome: "Desenvolvimento Mobile",
    duracao: "10 meses",
    turmas: 4,
    alunos: 98,
    status: "ativo",
  },
]

export default function CursosPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gerenciamento de Cursos e Trilhas</h1>
          <p className="text-muted-foreground">Gerencie todos os cursos e trilhas da plataforma.</p>
        </div>
        <Link href="/dashboard/cursos/novo">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Adicionar Curso
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 flex-1">
          <Input placeholder="Buscar cursos..." />
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Duração</TableHead>
              <TableHead>Turmas</TableHead>
              <TableHead>Alunos</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {cursos.map((curso) => (
              <TableRow key={curso.id}>
                <TableCell className="font-medium">{curso.nome}</TableCell>
                <TableCell>{curso.duracao}</TableCell>
                <TableCell>{curso.turmas}</TableCell>
                <TableCell>{curso.alunos}</TableCell>
                <TableCell>
                  <Badge variant="outline">{curso.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Link href={`/dashboard/cursos/${curso.id}`}>
                    <Button variant="ghost" size="sm">
                      Ver detalhes
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
