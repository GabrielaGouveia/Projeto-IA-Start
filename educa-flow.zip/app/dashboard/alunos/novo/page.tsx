"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { DatePicker } from "@/components/ui/date-picker"
import { calculateAge } from "@/lib/utils"

export default function NovoAlunoPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [dataNascimento, setDataNascimento] = useState<Date | undefined>(undefined)
  const [deficiente, setDeficiente] = useState(false)
  const [idade, setIdade] = useState<number | null>(null)
  const [estudante, setEstudante] = useState(true)
  const [possuiConexoes, setPossuiConexoes] = useState(false)

  // Atualiza a idade quando a data de nascimento muda
  const handleDataNascimentoChange = (date: Date | undefined) => {
    setDataNascimento(date)
    if (date) {
      setIdade(calculateAge(date))
    } else {
      setIdade(null)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulando envio do formulário
    setTimeout(() => {
      setIsLoading(false)
      alert("Aluno cadastrado com sucesso!")
      router.push("/dashboard/alunos")
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/alunos">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Cadastro de Novo Aluno</h1>
          <p className="text-muted-foreground">Preencha o formulário com os dados do novo aluno.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Dados Pessoais */}
        <Card>
          <CardHeader>
            <CardTitle>Dados Pessoais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nome">
                  Nome <span className="text-red-500">*</span>
                </Label>
                <Input id="nome" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataNascimento">
                  Data de Nascimento <span className="text-red-500">*</span>
                </Label>
                <DatePicker
                  id="dataNascimento"
                  selected={dataNascimento}
                  onSelect={handleDataNascimentoChange}
                  required
                  locale={ptBR}
                  placeholderText="DD/MM/AAAA"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sexo">
                  Sexo <span className="text-red-500">*</span>
                </Label>
                <Select required>
                  <SelectTrigger id="sexo">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="masculino">Masculino</SelectItem>
                    <SelectItem value="feminino">Feminino</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="naturalidade">Naturalidade</Label>
                <Input id="naturalidade" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ufNaturalidade">UF Naturalidade</Label>
                <Select>
                  <SelectTrigger id="ufNaturalidade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AC">Acre</SelectItem>
                    <SelectItem value="AL">Alagoas</SelectItem>
                    <SelectItem value="AP">Amapá</SelectItem>
                    <SelectItem value="AM">Amazonas</SelectItem>
                    <SelectItem value="BA">Bahia</SelectItem>
                    <SelectItem value="CE">Ceará</SelectItem>
                    <SelectItem value="DF">Distrito Federal</SelectItem>
                    <SelectItem value="ES">Espírito Santo</SelectItem>
                    <SelectItem value="GO">Goiás</SelectItem>
                    <SelectItem value="MA">Maranhão</SelectItem>
                    <SelectItem value="MT">Mato Grosso</SelectItem>
                    <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                    <SelectItem value="MG">Minas Gerais</SelectItem>
                    <SelectItem value="PA">Pará</SelectItem>
                    <SelectItem value="PB">Paraíba</SelectItem>
                    <SelectItem value="PR">Paraná</SelectItem>
                    <SelectItem value="PE">Pernambuco</SelectItem>
                    <SelectItem value="PI">Piauí</SelectItem>
                    <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                    <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                    <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                    <SelectItem value="RO">Rondônia</SelectItem>
                    <SelectItem value="RR">Roraima</SelectItem>
                    <SelectItem value="SC">Santa Catarina</SelectItem>
                    <SelectItem value="SP">São Paulo</SelectItem>
                    <SelectItem value="SE">Sergipe</SelectItem>
                    <SelectItem value="TO">Tocantins</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="raca">
                  Raça <span className="text-red-500">*</span>
                </Label>
                <Select required>
                  <SelectTrigger id="raca">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="branca">Branca</SelectItem>
                    <SelectItem value="preta">Preta</SelectItem>
                    <SelectItem value="parda">Parda</SelectItem>
                    <SelectItem value="amarela">Amarela</SelectItem>
                    <SelectItem value="indigena">Indígena</SelectItem>
                    <SelectItem value="nao_declarada">Não declarada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox id="lgbt" />
                <Label htmlFor="lgbt">Grupo LGBT</Label>
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox
                  id="deficiente"
                  checked={deficiente}
                  onCheckedChange={(checked) => setDeficiente(checked === true)}
                />
                <Label htmlFor="deficiente">Deficiente</Label>
              </div>
              {deficiente && (
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="tipoDeficiencia">Tipo de Deficiência</Label>
                  <Input id="tipoDeficiencia" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Informações de Contato */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Contato</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telefonePrincipal">
                  Telefone Principal <span className="text-red-500">*</span>
                </Label>
                <Input id="telefonePrincipal" type="tel" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telefoneSecundario">Telefone Secundário</Label>
                <Input id="telefoneSecundario" type="tel" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Endereço de E-mail</Label>
                <Input id="email" type="email" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Cadastro e Participação */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Cadastro e Participação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dataCadastro">Data de Cadastro</Label>
                <Input id="dataCadastro" value={format(new Date(), "dd/MM/yyyy")} disabled />
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox
                  id="estudante"
                  checked={estudante}
                  onCheckedChange={(checked) => setEstudante(checked === true)}
                />
                <Label htmlFor="estudante">Estudante</Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="projeto">
                  Nome do Projeto <span className="text-red-500">*</span>
                </Label>
                <Select required>
                  <SelectTrigger id="projeto">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dev-web">Desenvolvimento Web Full Stack</SelectItem>
                    <SelectItem value="data-science">Ciência de Dados</SelectItem>
                    <SelectItem value="ux-ui">Design de Experiência do Usuário</SelectItem>
                    <SelectItem value="devops">DevOps & Cloud</SelectItem>
                    <SelectItem value="mobile">Desenvolvimento Mobile</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="codigoProjeto">Código do Projeto</Label>
                <Input id="codigoProjeto" value="PROJ-2023" disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataIngresso">
                  Data de Ingresso no Projeto <span className="text-red-500">*</span>
                </Label>
                <DatePicker id="dataIngresso" required locale={ptBR} placeholderText="DD/MM/AAAA" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataSaida">Data de Saída no Projeto</Label>
                <DatePicker id="dataSaida" locale={ptBR} placeholderText="DD/MM/AAAA" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unidade">
                  Unidade <span className="text-red-500">*</span>
                </Label>
                <Select required>
                  <SelectTrigger id="unidade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unidade-1">Unidade Centro</SelectItem>
                    <SelectItem value="unidade-2">Unidade Norte</SelectItem>
                    <SelectItem value="unidade-3">Unidade Sul</SelectItem>
                    <SelectItem value="unidade-4">Unidade Leste</SelectItem>
                    <SelectItem value="unidade-5">Unidade Oeste</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="codigoUnidade">Código da Unidade</Label>
                <Input id="codigoUnidade" value="UNID-001" disabled />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Localização */}
        <Card>
          <CardHeader>
            <CardTitle>Localização</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bairro">
                  Bairro <span className="text-red-500">*</span>
                </Label>
                <Input id="bairro" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cidade">
                  Cidade <span className="text-red-500">*</span>
                </Label>
                <Input id="cidade" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="uf">
                  UF <span className="text-red-500">*</span>
                </Label>
                <Select required>
                  <SelectTrigger id="uf">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AC">Acre</SelectItem>
                    <SelectItem value="AL">Alagoas</SelectItem>
                    <SelectItem value="AP">Amapá</SelectItem>
                    <SelectItem value="AM">Amazonas</SelectItem>
                    <SelectItem value="BA">Bahia</SelectItem>
                    <SelectItem value="CE">Ceará</SelectItem>
                    <SelectItem value="DF">Distrito Federal</SelectItem>
                    <SelectItem value="ES">Espírito Santo</SelectItem>
                    <SelectItem value="GO">Goiás</SelectItem>
                    <SelectItem value="MA">Maranhão</SelectItem>
                    <SelectItem value="MT">Mato Grosso</SelectItem>
                    <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                    <SelectItem value="MG">Minas Gerais</SelectItem>
                    <SelectItem value="PA">Pará</SelectItem>
                    <SelectItem value="PB">Paraíba</SelectItem>
                    <SelectItem value="PR">Paraná</SelectItem>
                    <SelectItem value="PE">Pernambuco</SelectItem>
                    <SelectItem value="PI">Piauí</SelectItem>
                    <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                    <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                    <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                    <SelectItem value="RO">Rondônia</SelectItem>
                    <SelectItem value="RR">Roraima</SelectItem>
                    <SelectItem value="SC">Santa Catarina</SelectItem>
                    <SelectItem value="SP">São Paulo</SelectItem>
                    <SelectItem value="SE">Sergipe</SelectItem>
                    <SelectItem value="TO">Tocantins</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Socioeconômicas */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Socioeconômicas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rendaPerCapta">Renda Per Capita</Label>
                <Input id="rendaPerCapta" type="number" step="0.01" min="0" />
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox id="conflitoLei" />
                <Label htmlFor="conflitoLei">Conflito com a Lei</Label>
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox id="cadUnico" />
                <Label htmlFor="cadUnico">Possui Cad Único</Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pessoasMoram">Pessoas que Moram na Residência</Label>
                <Input id="pessoasMoram" type="number" min="1" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pessoasTrabalham">Pessoas que Trabalham na Residência</Label>
                <Input id="pessoasTrabalham" type="number" min="0" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rendaPropria">Renda Própria</Label>
                <Input id="rendaPropria" type="number" step="0.01" min="0" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rendaFamiliar">Renda Familiar</Label>
                <Input id="rendaFamiliar" type="number" step="0.01" min="0" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vulnerabilidadeSocial">Vulnerabilidade Social</Label>
                <Select>
                  <SelectTrigger id="vulnerabilidadeSocial">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="baixa">Baixa</SelectItem>
                    <SelectItem value="media">Média</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="extrema">Extrema</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Específicas */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Específicas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="idade">Idade</Label>
                <Input id="idade" value={idade !== null ? idade.toString() : ""} disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="nivelEnsino">Nível de Ensino</Label>
                <Select>
                  <SelectTrigger id="nivelEnsino">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fundamental">Fundamental</SelectItem>
                    <SelectItem value="medio">Médio</SelectItem>
                    <SelectItem value="superior">Superior</SelectItem>
                    <SelectItem value="tecnico">Técnico</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="anoSerie">Ano/Série</Label>
                <Input id="anoSerie" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="numeroFilhos">Número de Filhos</Label>
                <Input id="numeroFilhos" type="number" min="0" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="dificuldadeLocomocao">Dificuldade de Locomoção</Label>
                <Input id="dificuldadeLocomocao" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Objetivos Profissionais */}
        <Card>
          <CardHeader>
            <CardTitle>Objetivos Profissionais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="interessesProfissionais">Interesses Profissionais</Label>
                <Textarea id="interessesProfissionais" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="objetivosCurtoPrazo">Objetivos de Curto Prazo</Label>
                <Textarea id="objetivosCurtoPrazo" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="objetivosLongoPrazo">Objetivos de Longo Prazo</Label>
                <Textarea id="objetivosLongoPrazo" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="experienciaAnterior">Experiência Profissional Anterior</Label>
                <Textarea id="experienciaAnterior" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="habilidadesCompetencias">Habilidades e Competências</Label>
                <Textarea id="habilidadesCompetencias" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Contato dos Responsáveis (Condicional para menores de 18 anos) */}
        {idade !== null && idade < 18 && (
          <Card>
            <CardHeader>
              <CardTitle>Informações de Contato dos Responsáveis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nomeResponsavel1">Nome do Responsável 1</Label>
                  <Input id="nomeResponsavel1" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefoneResponsavel1">Telefone do Responsável 1</Label>
                  <Input id="telefoneResponsavel1" type="tel" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emailResponsavel1">E-mail do Responsável 1</Label>
                  <Input id="emailResponsavel1" type="email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parentescoResponsavel1">Grau de Parentesco do Responsável 1</Label>
                  <Input id="parentescoResponsavel1" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nomeResponsavel2">Nome do Responsável 2</Label>
                  <Input id="nomeResponsavel2" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefoneResponsavel2">Telefone do Responsável 2</Label>
                  <Input id="telefoneResponsavel2" type="tel" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emailResponsavel2">E-mail do Responsável 2</Label>
                  <Input id="emailResponsavel2" type="email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parentescoResponsavel2">Grau de Parentesco do Responsável 2</Label>
                  <Input id="parentescoResponsavel2" />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Informações sobre o Curso e Expectativas */}
        <Card>
          <CardHeader>
            <CardTitle>Informações sobre o Curso e Expectativas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="motivoEscolhaCurso">Motivo da Escolha do Curso</Label>
                <Textarea id="motivoEscolhaCurso" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expectativasCurso">Expectativas em Relação ao Curso</Label>
                <Textarea id="expectativasCurso" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="disponibilidadeHorario">Disponibilidade de Horário para Estudo</Label>
                <Textarea id="disponibilidadeHorario" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="preferenciasAprendizagem">Preferências de Aprendizagem</Label>
                <Textarea id="preferenciasAprendizagem" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recursosDigitais">Recursos Digitais Disponíveis</Label>
                <Textarea id="recursosDigitais" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Histórico Educacional e Profissional Mais Detalhado */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico Educacional e Profissional</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ultimoNivelEscolaridade">Último Nível de Escolaridade Concluído</Label>
                <Select>
                  <SelectTrigger id="ultimoNivelEscolaridade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fundamental_incompleto">Ensino Fundamental Incompleto</SelectItem>
                    <SelectItem value="fundamental_completo">Ensino Fundamental Completo</SelectItem>
                    <SelectItem value="medio_incompleto">Ensino Médio Incompleto</SelectItem>
                    <SelectItem value="medio_completo">Ensino Médio Completo</SelectItem>
                    <SelectItem value="tecnico_incompleto">Ensino Técnico Incompleto</SelectItem>
                    <SelectItem value="tecnico_completo">Ensino Técnico Completo</SelectItem>
                    <SelectItem value="superior_incompleto">Ensino Superior Incompleto</SelectItem>
                    <SelectItem value="superior_completo">Ensino Superior Completo</SelectItem>
                    <SelectItem value="pos_graduacao">Pós-Graduação</SelectItem>
                    <SelectItem value="mestrado">Mestrado</SelectItem>
                    <SelectItem value="doutorado">Doutorado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="instituicaoUltimoNivel">Instituição do Último Nível de Escolaridade</Label>
                <Input id="instituicaoUltimoNivel" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="cursosAnteriores">Cursos Anteriores</Label>
                <Textarea id="cursosAnteriores" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="experienciaProfissionalArea">Experiência Profissional na Área</Label>
                <Textarea id="experienciaProfissionalArea" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tempoExperiencia">Tempo de Experiência Profissional na Área</Label>
                <Input id="tempoExperiencia" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="principaisAtividades">Principais Atividades na Área Profissional</Label>
                <Textarea id="principaisAtividades" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="interesseAreasEspecificas">Interesse em Áreas Específicas Dentro da Profissão</Label>
                <Textarea id="interesseAreasEspecificas" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Rede e Mentoria */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Rede e Mentoria</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox
                  id="possuiConexoes"
                  checked={possuiConexoes}
                  onCheckedChange={(checked) => setPossuiConexoes(checked === true)}
                />
                <Label htmlFor="possuiConexoes">Possui Conexões Profissionais na Área?</Label>
              </div>
              {possuiConexoes && (
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="detalhesConexoes">Detalhes das Conexões Profissionais</Label>
                  <Textarea id="detalhesConexoes" />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="interesseMentoria">Interesse em Mentoria?</Label>
                <Select>
                  <SelectTrigger id="interesseMentoria">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mentor">Mentor</SelectItem>
                    <SelectItem value="mentorado">Mentorado</SelectItem>
                    <SelectItem value="nao">Não</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Comportamentais e de Desenvolvimento Pessoal */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Comportamentais e de Desenvolvimento Pessoal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="autoavaliacaoLideranca">Autoavaliação de Habilidades (Liderança)</Label>
                <Select>
                  <SelectTrigger id="autoavaliacaoLideranca">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Muito baixo</SelectItem>
                    <SelectItem value="2">2 - Baixo</SelectItem>
                    <SelectItem value="3">3 - Médio</SelectItem>
                    <SelectItem value="4">4 - Alto</SelectItem>
                    <SelectItem value="5">5 - Muito alto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="autoavaliacaoComunicacao">Autoavaliação de Habilidades (Comunicação)</Label>
                <Select>
                  <SelectTrigger id="autoavaliacaoComunicacao">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Muito baixo</SelectItem>
                    <SelectItem value="2">2 - Baixo</SelectItem>
                    <SelectItem value="3">3 - Médio</SelectItem>
                    <SelectItem value="4">4 - Alto</SelectItem>
                    <SelectItem value="5">5 - Muito alto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="autoavaliacaoTrabalhoEquipe">Autoavaliação de Habilidades (Trabalho em Equipe)</Label>
                <Select>
                  <SelectTrigger id="autoavaliacaoTrabalhoEquipe">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Muito baixo</SelectItem>
                    <SelectItem value="2">2 - Baixo</SelectItem>
                    <SelectItem value="3">3 - Médio</SelectItem>
                    <SelectItem value="4">4 - Alto</SelectItem>
                    <SelectItem value="5">5 - Muito alto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="outrasAutoavaliacoes">Outras Autoavaliações de Habilidades</Label>
                <Textarea id="outrasAutoavaliacoes" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="objetivosDesenvolvimentoPessoal">Objetivos de Desenvolvimento Pessoal</Label>
                <Textarea id="objetivosDesenvolvimentoPessoal" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expectativasSalariais">Expectativas Salariais</Label>
                <Select>
                  <SelectTrigger id="expectativasSalariais">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ate_1000">Até R$ 1.000</SelectItem>
                    <SelectItem value="1001_2000">R$ 1.001 a R$ 2.000</SelectItem>
                    <SelectItem value="2001_3000">R$ 2.001 a R$ 3.000</SelectItem>
                    <SelectItem value="3001_4000">R$ 3.001 a R$ 4.000</SelectItem>
                    <SelectItem value="4001_5000">R$ 4.001 a R$ 5.000</SelectItem>
                    <SelectItem value="acima_5000">Acima de R$ 5.000</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Link href="/dashboard/alunos">
            <Button variant="outline" type="button">
              Cancelar
            </Button>
          </Link>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Salvando..." : "Salvar Aluno"}
          </Button>
        </div>
      </form>
    </div>
  )
}
