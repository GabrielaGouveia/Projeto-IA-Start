"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { DatePicker } from "@/components/ui/date-picker"
import { calculateAge } from "@/lib/utils"

export default function EditarAlunoPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [aluno, setAluno] = useState<any>(null)
  const [dataNascimento, setDataNascimento] = useState<Date | undefined>(undefined)
  const [deficiente, setDeficiente] = useState(false)
  const [idade, setIdade] = useState<number | null>(null)
  const [estudante, setEstudante] = useState(true)
  const [possuiConexoes, setPossuiConexoes] = useState(false)

  // Simulando carregamento dos dados do aluno
  useEffect(() => {
    // Em um cenário real, aqui seria feita uma requisição para buscar os dados do aluno pelo ID
    const alunoSimulado = {
      id: params.id,
      nome: "Ana Silva",
      email: "ana.silva@exemplo.com",
      telefone: "(11) 98765-4321",
      telefoneSecundario: "(11) 3456-7890",
      endereco: "Rua das Flores, 123 - São Paulo, SP",
      dataNascimento: new Date("1995-05-15"),
      sexo: "feminino",
      naturalidade: "São Paulo",
      ufNaturalidade: "SP",
      raca: "parda",
      lgbt: false,
      deficiente: false,
      tipoDeficiencia: "",
      turma: "Desenvolvimento Web - Turma 3",
      curso: "Desenvolvimento Web Full Stack",
      risco: "baixo",
      dataCadastro: new Date("2023-01-15"),
      estudante: true,
      projeto: "dev-web",
      codigoProjeto: "PROJ-2023",
      dataIngresso: new Date("2023-02-01"),
      dataSaida: null,
      unidade: "unidade-1",
      codigoUnidade: "UNID-001",
      bairro: "Centro",
      cidade: "São Paulo",
      uf: "SP",
      rendaPerCapta: 1200,
      conflitoLei: false,
      cadUnico: true,
      pessoasMoram: 3,
      pessoasTrabalham: 2,
      rendaPropria: 2000,
      rendaFamiliar: 4500,
      vulnerabilidadeSocial: "média",
      nivelEnsino: "superior",
      anoSerie: "3º ano",
      numeroFilhos: 0,
      dificuldadeLocomocao: "Nenhuma",
      interessesProfissionais: "Desenvolvimento web, mobile e inteligência artificial",
      objetivosCurtoPrazo: "Concluir o curso e conseguir um estágio na área",
      objetivosLongoPrazo: "Trabalhar como desenvolvedora full stack em uma empresa de tecnologia",
      experienciaAnterior: "Estágio de 6 meses como desenvolvedora front-end",
      habilidadesCompetencias: "HTML, CSS, JavaScript, React básico",
      nomeResponsavel1: "",
      telefoneResponsavel1: "",
      emailResponsavel1: "",
      parentescoResponsavel1: "",
      nomeResponsavel2: "",
      telefoneResponsavel2: "",
      emailResponsavel2: "",
      parentescoResponsavel2: "",
      motivoEscolhaCurso: "Interesse em desenvolvimento web e oportunidades de carreira na área",
      expectativasCurso: "Aprender tecnologias modernas e estar preparada para o mercado de trabalho",
      disponibilidadeHorario: "Período noturno e finais de semana",
      preferenciasAprendizagem: "Aulas práticas e projetos reais",
      recursosDigitais: "Computador próprio e acesso à internet",
      ultimoNivelEscolaridade: "superior_incompleto",
      instituicaoUltimoNivel: "Universidade de São Paulo",
      cursosAnteriores: "Curso básico de HTML e CSS",
      experienciaProfissionalArea: "Estágio como desenvolvedora front-end",
      tempoExperiencia: "6 meses",
      principaisAtividades: "Desenvolvimento de interfaces de usuário com HTML, CSS e JavaScript",
      interesseAreasEspecificas: "Front-end e UX/UI",
      possuiConexoes: true,
      detalhesConexoes: "Contatos em empresas de tecnologia através de networking em eventos",
      interesseMentoria: "mentorado",
      autoavaliacaoLideranca: "3",
      autoavaliacaoComunicacao: "4",
      autoavaliacaoTrabalhoEquipe: "4",
      outrasAutoavaliacoes: "Boa capacidade de aprendizado e adaptação",
      objetivosDesenvolvimentoPessoal: "Melhorar habilidades de comunicação e liderança",
      expectativasSalariais: "3001_4000",
    }

    setAluno(alunoSimulado)
    setDataNascimento(alunoSimulado.dataNascimento)
    setDeficiente(alunoSimulado.deficiente)
    setEstudante(alunoSimulado.estudante)
    setPossuiConexoes(alunoSimulado.possuiConexoes)

    if (alunoSimulado.dataNascimento) {
      setIdade(calculateAge(alunoSimulado.dataNascimento))
    }
  }, [params.id])

  // Atualiza a idade quando a data de nascimento muda
  const handleDataNascimentoChange = (date: Date | undefined) => {
    setDataNascimento(date)
    if (date) {
      setIdade(calculateAge(date))
    } else {
      setIdade(null)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulando envio do formulário
    setTimeout(() => {
      setIsLoading(false)
      alert("Dados do aluno atualizados com sucesso!")
      router.push(`/dashboard/alunos/${params.id}`)
    }, 1500)
  }

  if (!aluno) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p>Carregando dados do aluno...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href={`/dashboard/alunos/${params.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Editar Aluno</h1>
          <p className="text-muted-foreground">Atualize os dados do aluno.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Dados Pessoais */}
        <Card>
          <CardHeader>
            <CardTitle>Dados Pessoais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nome">
                  Nome <span className="text-red-500">*</span>
                </Label>
                <Input id="nome" defaultValue={aluno.nome} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataNascimento">
                  Data de Nascimento <span className="text-red-500">*</span>
                </Label>
                <DatePicker
                  id="dataNascimento"
                  selected={dataNascimento}
                  onSelect={handleDataNascimentoChange}
                  required
                  locale={ptBR}
                  placeholderText="DD/MM/AAAA"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sexo">
                  Sexo <span className="text-red-500">*</span>
                </Label>
                <Select defaultValue={aluno.sexo} required>
                  <SelectTrigger id="sexo">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="masculino">Masculino</SelectItem>
                    <SelectItem value="feminino">Feminino</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="naturalidade">Naturalidade</Label>
                <Input id="naturalidade" defaultValue={aluno.naturalidade} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ufNaturalidade">UF Naturalidade</Label>
                <Select defaultValue={aluno.ufNaturalidade}>
                  <SelectTrigger id="ufNaturalidade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AC">Acre</SelectItem>
                    <SelectItem value="AL">Alagoas</SelectItem>
                    <SelectItem value="AP">Amapá</SelectItem>
                    <SelectItem value="AM">Amazonas</SelectItem>
                    <SelectItem value="BA">Bahia</SelectItem>
                    <SelectItem value="CE">Ceará</SelectItem>
                    <SelectItem value="DF">Distrito Federal</SelectItem>
                    <SelectItem value="ES">Espírito Santo</SelectItem>
                    <SelectItem value="GO">Goiás</SelectItem>
                    <SelectItem value="MA">Maranhão</SelectItem>
                    <SelectItem value="MT">Mato Grosso</SelectItem>
                    <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                    <SelectItem value="MG">Minas Gerais</SelectItem>
                    <SelectItem value="PA">Pará</SelectItem>
                    <SelectItem value="PB">Paraíba</SelectItem>
                    <SelectItem value="PR">Paraná</SelectItem>
                    <SelectItem value="PE">Pernambuco</SelectItem>
                    <SelectItem value="PI">Piauí</SelectItem>
                    <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                    <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                    <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                    <SelectItem value="RO">Rondônia</SelectItem>
                    <SelectItem value="RR">Roraima</SelectItem>
                    <SelectItem value="SC">Santa Catarina</SelectItem>
                    <SelectItem value="SP">São Paulo</SelectItem>
                    <SelectItem value="SE">Sergipe</SelectItem>
                    <SelectItem value="TO">Tocantins</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="raca">
                  Raça <span className="text-red-500">*</span>
                </Label>
                <Select defaultValue={aluno.raca} required>
                  <SelectTrigger id="raca">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="branca">Branca</SelectItem>
                    <SelectItem value="preta">Preta</SelectItem>
                    <SelectItem value="parda">Parda</SelectItem>
                    <SelectItem value="amarela">Amarela</SelectItem>
                    <SelectItem value="indigena">Indígena</SelectItem>
                    <SelectItem value="nao_declarada">Não declarada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox id="lgbt" defaultChecked={aluno.lgbt} />
                <Label htmlFor="lgbt">Grupo LGBT</Label>
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox
                  id="deficiente"
                  checked={deficiente}
                  onCheckedChange={(checked) => setDeficiente(checked === true)}
                  defaultChecked={aluno.deficiente}
                />
                <Label htmlFor="deficiente">Deficiente</Label>
              </div>
              {deficiente && (
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="tipoDeficiencia">Tipo de Deficiência</Label>
                  <Input id="tipoDeficiencia" defaultValue={aluno.tipoDeficiencia} />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Informações de Contato */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Contato</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="telefonePrincipal">
                  Telefone Principal <span className="text-red-500">*</span>
                </Label>
                <Input id="telefonePrincipal" type="tel" defaultValue={aluno.telefone} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telefoneSecundario">Telefone Secundário</Label>
                <Input id="telefoneSecundario" type="tel" defaultValue={aluno.telefoneSecundario} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Endereço de E-mail</Label>
                <Input id="email" type="email" defaultValue={aluno.email} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Cadastro e Participação */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Cadastro e Participação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dataCadastro">Data de Cadastro</Label>
                <Input id="dataCadastro" value={format(aluno.dataCadastro, "dd/MM/yyyy")} disabled />
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox
                  id="estudante"
                  checked={estudante}
                  onCheckedChange={(checked) => setEstudante(checked === true)}
                  defaultChecked={aluno.estudante}
                />
                <Label htmlFor="estudante">Estudante</Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="projeto">
                  Nome do Projeto <span className="text-red-500">*</span>
                </Label>
                <Select defaultValue={aluno.projeto} required>
                  <SelectTrigger id="projeto">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dev-web">Desenvolvimento Web Full Stack</SelectItem>
                    <SelectItem value="data-science">Ciência de Dados</SelectItem>
                    <SelectItem value="ux-ui">Design de Experiência do Usuário</SelectItem>
                    <SelectItem value="devops">DevOps & Cloud</SelectItem>
                    <SelectItem value="mobile">Desenvolvimento Mobile</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="codigoProjeto">Código do Projeto</Label>
                <Input id="codigoProjeto" value={aluno.codigoProjeto} disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataIngresso">
                  Data de Ingresso no Projeto <span className="text-red-500">*</span>
                </Label>
                <DatePicker
                  id="dataIngresso"
                  required
                  locale={ptBR}
                  placeholderText="DD/MM/AAAA"
                  selected={aluno.dataIngresso}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dataSaida">Data de Saída no Projeto</Label>
                <DatePicker id="dataSaida" locale={ptBR} placeholderText="DD/MM/AAAA" selected={aluno.dataSaida} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unidade">
                  Unidade <span className="text-red-500">*</span>
                </Label>
                <Select defaultValue={aluno.unidade} required>
                  <SelectTrigger id="unidade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unidade-1">Unidade Centro</SelectItem>
                    <SelectItem value="unidade-2">Unidade Norte</SelectItem>
                    <SelectItem value="unidade-3">Unidade Sul</SelectItem>
                    <SelectItem value="unidade-4">Unidade Leste</SelectItem>
                    <SelectItem value="unidade-5">Unidade Oeste</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="codigoUnidade">Código da Unidade</Label>
                <Input id="codigoUnidade" value={aluno.codigoUnidade} disabled />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Localização */}
        <Card>
          <CardHeader>
            <CardTitle>Localização</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bairro">
                  Bairro <span className="text-red-500">*</span>
                </Label>
                <Input id="bairro" defaultValue={aluno.bairro} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cidade">
                  Cidade <span className="text-red-500">*</span>
                </Label>
                <Input id="cidade" defaultValue={aluno.cidade} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="uf">
                  UF <span className="text-red-500">*</span>
                </Label>
                <Select defaultValue={aluno.uf} required>
                  <SelectTrigger id="uf">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AC">Acre</SelectItem>
                    <SelectItem value="AL">Alagoas</SelectItem>
                    <SelectItem value="AP">Amapá</SelectItem>
                    <SelectItem value="AM">Amazonas</SelectItem>
                    <SelectItem value="BA">Bahia</SelectItem>
                    <SelectItem value="CE">Ceará</SelectItem>
                    <SelectItem value="DF">Distrito Federal</SelectItem>
                    <SelectItem value="ES">Espírito Santo</SelectItem>
                    <SelectItem value="GO">Goiás</SelectItem>
                    <SelectItem value="MA">Maranhão</SelectItem>
                    <SelectItem value="MT">Mato Grosso</SelectItem>
                    <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                    <SelectItem value="MG">Minas Gerais</SelectItem>
                    <SelectItem value="PA">Pará</SelectItem>
                    <SelectItem value="PB">Paraíba</SelectItem>
                    <SelectItem value="PR">Paraná</SelectItem>
                    <SelectItem value="PE">Pernambuco</SelectItem>
                    <SelectItem value="PI">Piauí</SelectItem>
                    <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                    <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                    <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                    <SelectItem value="RO">Rondônia</SelectItem>
                    <SelectItem value="RR">Roraima</SelectItem>
                    <SelectItem value="SC">Santa Catarina</SelectItem>
                    <SelectItem value="SP">São Paulo</SelectItem>
                    <SelectItem value="SE">Sergipe</SelectItem>
                    <SelectItem value="TO">Tocantins</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Socioeconômicas */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Socioeconômicas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rendaPerCapta">Renda Per Capita</Label>
                <Input id="rendaPerCapta" type="number" step="0.01" min="0" defaultValue={aluno.rendaPerCapta} />
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox id="conflitoLei" defaultChecked={aluno.conflitoLei} />
                <Label htmlFor="conflitoLei">Conflito com a Lei</Label>
              </div>
              <div className="flex items-center space-x-2 pt-6">
                <Checkbox id="cadUnico" defaultChecked={aluno.cadUnico} />
                <Label htmlFor="cadUnico">Possui Cad Único</Label>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pessoasMoram">Pessoas que Moram na Residência</Label>
                <Input id="pessoasMoram" type="number" min="1" defaultValue={aluno.pessoasMoram} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pessoasTrabalham">Pessoas que Trabalham na Residência</Label>
                <Input id="pessoasTrabalham" type="number" min="0" defaultValue={aluno.pessoasTrabalham} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rendaPropria">Renda Própria</Label>
                <Input id="rendaPropria" type="number" step="0.01" min="0" defaultValue={aluno.rendaPropria} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rendaFamiliar">Renda Familiar</Label>
                <Input id="rendaFamiliar" type="number" step="0.01" min="0" defaultValue={aluno.rendaFamiliar} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vulnerabilidadeSocial">Vulnerabilidade Social</Label>
                <Select defaultValue={aluno.vulnerabilidadeSocial}>
                  <SelectTrigger id="vulnerabilidadeSocial">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="baixa">Baixa</SelectItem>
                    <SelectItem value="média">Média</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                    <SelectItem value="extrema">Extrema</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Específicas */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Específicas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="idade">Idade</Label>
                <Input id="idade" value={idade !== null ? idade.toString() : ""} disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="nivelEnsino">Nível de Ensino</Label>
                <Select defaultValue={aluno.nivelEnsino}>
                  <SelectTrigger id="nivelEnsino">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fundamental">Fundamental</SelectItem>
                    <SelectItem value="medio">Médio</SelectItem>
                    <SelectItem value="superior">Superior</SelectItem>
                    <SelectItem value="tecnico">Técnico</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="anoSerie">Ano/Série</Label>
                <Input id="anoSerie" defaultValue={aluno.anoSerie} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="numeroFilhos">Número de Filhos</Label>
                <Input id="numeroFilhos" type="number" min="0" defaultValue={aluno.numeroFilhos} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="dificuldadeLocomocao">Dificuldade de Locomoção</Label>
                <Input id="dificuldadeLocomocao" defaultValue={aluno.dificuldadeLocomocao} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Objetivos Profissionais */}
        <Card>
          <CardHeader>
            <CardTitle>Objetivos Profissionais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="interessesProfissionais">Interesses Profissionais</Label>
                <Textarea id="interessesProfissionais" defaultValue={aluno.interessesProfissionais} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="objetivosCurtoPrazo">Objetivos de Curto Prazo</Label>
                <Textarea id="objetivosCurtoPrazo" defaultValue={aluno.objetivosCurtoPrazo} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="objetivosLongoPrazo">Objetivos de Longo Prazo</Label>
                <Textarea id="objetivosLongoPrazo" defaultValue={aluno.objetivosLongoPrazo} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="experienciaAnterior">Experiência Profissional Anterior</Label>
                <Textarea id="experienciaAnterior" defaultValue={aluno.experienciaAnterior} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="habilidadesCompetencias">Habilidades e Competências</Label>
                <Textarea id="habilidadesCompetencias" defaultValue={aluno.habilidadesCompetencias} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Contato dos Responsáveis (Condicional para menores de 18 anos) */}
        {idade !== null && idade < 18 && (
          <Card>
            <CardHeader>
              <CardTitle>Informações de Contato dos Responsáveis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nomeResponsavel1">Nome do Responsável 1</Label>
                  <Input id="nomeResponsavel1" defaultValue={aluno.nomeResponsavel1} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefoneResponsavel1">Telefone do Responsável 1</Label>
                  <Input id="telefoneResponsavel1" type="tel" defaultValue={aluno.telefoneResponsavel1} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emailResponsavel1">E-mail do Responsável 1</Label>
                  <Input id="emailResponsavel1" type="email" defaultValue={aluno.emailResponsavel1} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parentescoResponsavel1">Grau de Parentesco do Responsável 1</Label>
                  <Input id="parentescoResponsavel1" defaultValue={aluno.parentescoResponsavel1} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nomeResponsavel2">Nome do Responsável 2</Label>
                  <Input id="nomeResponsavel2" defaultValue={aluno.nomeResponsavel2} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefoneResponsavel2">Telefone do Responsável 2</Label>
                  <Input id="telefoneResponsavel2" type="tel" defaultValue={aluno.telefoneResponsavel2} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emailResponsavel2">E-mail do Responsável 2</Label>
                  <Input id="emailResponsavel2" type="email" defaultValue={aluno.emailResponsavel2} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parentescoResponsavel2">Grau de Parentesco do Responsável 2</Label>
                  <Input id="parentescoResponsavel2" defaultValue={aluno.parentescoResponsavel2} />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Informações sobre o Curso e Expectativas */}
        <Card>
          <CardHeader>
            <CardTitle>Informações sobre o Curso e Expectativas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label htmlFor="motivoEscolhaCurso">Motivo da Escolha do Curso</Label>
                <Textarea id="motivoEscolhaCurso" defaultValue={aluno.motivoEscolhaCurso} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expectativasCurso">Expectativas em Relação ao Curso</Label>
                <Textarea id="expectativasCurso" defaultValue={aluno.expectativasCurso} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="disponibilidadeHorario">Disponibilidade de Horário para Estudo</Label>
                <Textarea id="disponibilidadeHorario" defaultValue={aluno.disponibilidadeHorario} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="preferenciasAprendizagem">Preferências de Aprendizagem</Label>
                <Textarea id="preferenciasAprendizagem" defaultValue={aluno.preferenciasAprendizagem} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recursosDigitais">Recursos Digitais Disponíveis</Label>
                <Textarea id="recursosDigitais" defaultValue={aluno.recursosDigitais} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Histórico Educacional e Profissional Mais Detalhado */}
        <Card>
          <CardHeader>
            <CardTitle>Histórico Educacional e Profissional</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ultimoNivelEscolaridade">Último Nível de Escolaridade Concluído</Label>
                <Select defaultValue={aluno.ultimoNivelEscolaridade}>
                  <SelectTrigger id="ultimoNivelEscolaridade">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fundamental_incompleto">Ensino Fundamental Incompleto</SelectItem>
                    <SelectItem value="fundamental_completo">Ensino Fundamental Completo</SelectItem>
                    <SelectItem value="medio_incompleto">Ensino Médio Incompleto</SelectItem>
                    <SelectItem value="medio_completo">Ensino Médio Completo</SelectItem>
                    <SelectItem value="tecnico_incompleto">Ensino Técnico Incompleto</SelectItem>
                    <SelectItem value="tecnico_completo">Ensino Técnico Completo</SelectItem>
                    <SelectItem value="superior_incompleto">Ensino Superior Incompleto</SelectItem>
                    <SelectItem value="superior_completo">Ensino Superior Completo</SelectItem>
                    <SelectItem value="pos_graduacao">Pós-Graduação</SelectItem>
                    <SelectItem value="mestrado">Mestrado</SelectItem>
                    <SelectItem value="doutorado">Doutorado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="instituicaoUltimoNivel">Instituição do Último Nível de Escolaridade</Label>
                <Input id="instituicaoUltimoNivel" defaultValue={aluno.instituicaoUltimoNivel} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="cursosAnteriores">Cursos Anteriores</Label>
                <Textarea id="cursosAnteriores" defaultValue={aluno.cursosAnteriores} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="experienciaProfissionalArea">Experiência Profissional na Área</Label>
                <Textarea id="experienciaProfissionalArea" defaultValue={aluno.experienciaProfissionalArea} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="tempoExperiencia">Tempo de Experiência Profissional na Área</Label>
                <Input id="tempoExperiencia" defaultValue={aluno.tempoExperiencia} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="principaisAtividades">Principais Atividades na Área Profissional</Label>
                <Textarea id="principaisAtividades" defaultValue={aluno.principaisAtividades} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="interesseAreasEspecificas">Interesse em Áreas Específicas Dentro da Profissão</Label>
                <Textarea id="interesseAreasEspecificas" defaultValue={aluno.interesseAreasEspecificas} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações de Rede e Mentoria */}
        <Card>
          <CardHeader>
            <CardTitle>Informações de Rede e Mentoria</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox
                  id="possuiConexoes"
                  checked={possuiConexoes}
                  onCheckedChange={(checked) => setPossuiConexoes(checked === true)}
                  defaultChecked={aluno.possuiConexoes}
                />
                <Label htmlFor="possuiConexoes">Possui Conexões Profissionais na Área?</Label>
              </div>
              {possuiConexoes && (
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="detalhesConexoes">Detalhes das Conexões Profissionais</Label>
                  <Textarea id="detalhesConexoes" defaultValue={aluno.detalhesConexoes} />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="interesseMentoria">Interesse em Mentoria?</Label>
                <Select defaultValue={aluno.interesseMentoria}>
                  <SelectTrigger id="interesseMentoria">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mentor">Mentor</SelectItem>
                    <SelectItem value="mentorado">Mentorado</SelectItem>
                    <SelectItem value="nao">Não</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Informações Comportamentais e de Desenvolvimento Pessoal */}
        <Card>
          <CardHeader>
            <CardTitle>Informações Comportamentais e de Desenvolvimento Pessoal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="autoavaliacaoLideranca">Autoavaliação de Habilidades (Liderança)</Label>
                <Select defaultValue={aluno.autoavaliacaoLideranca}>
                  <SelectTrigger id="autoavaliacaoLideranca">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Muito baixo</SelectItem>
                    <SelectItem value="2">2 - Baixo</SelectItem>
                    <SelectItem value="3">3 - Médio</SelectItem>
                    <SelectItem value="4">4 - Alto</SelectItem>
                    <SelectItem value="5">5 - Muito alto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="autoavaliacaoComunicacao">Autoavaliação de Habilidades (Comunicação)</Label>
                <Select defaultValue={aluno.autoavaliacaoComunicacao}>
                  <SelectTrigger id="autoavaliacaoComunicacao">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Muito baixo</SelectItem>
                    <SelectItem value="2">2 - Baixo</SelectItem>
                    <SelectItem value="3">3 - Médio</SelectItem>
                    <SelectItem value="4">4 - Alto</SelectItem>
                    <SelectItem value="5">5 - Muito alto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="autoavaliacaoTrabalhoEquipe">Autoavaliação de Habilidades (Trabalho em Equipe)</Label>
                <Select defaultValue={aluno.autoavaliacaoTrabalhoEquipe}>
                  <SelectTrigger id="autoavaliacaoTrabalhoEquipe">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 - Muito baixo</SelectItem>
                    <SelectItem value="2">2 - Baixo</SelectItem>
                    <SelectItem value="3">3 - Médio</SelectItem>
                    <SelectItem value="4">4 - Alto</SelectItem>
                    <SelectItem value="5">5 - Muito alto</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="outrasAutoavaliacoes">Outras Autoavaliações de Habilidades</Label>
                <Textarea id="outrasAutoavaliacoes" defaultValue={aluno.outrasAutoavaliacoes} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="objetivosDesenvolvimentoPessoal">Objetivos de Desenvolvimento Pessoal</Label>
                <Textarea id="objetivosDesenvolvimentoPessoal" defaultValue={aluno.objetivosDesenvolvimentoPessoal} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="expectativasSalariais">Expectativas Salariais</Label>
                <Select defaultValue={aluno.expectativasSalariais}>
                  <SelectTrigger id="expectativasSalariais">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ate_1000">Até R$ 1.000</SelectItem>
                    <SelectItem value="1001_2000">R$ 1.001 a R$ 2.000</SelectItem>
                    <SelectItem value="2001_3000">R$ 2.001 a R$ 3.000</SelectItem>
                    <SelectItem value="3001_4000">R$ 3.001 a R$ 4.000</SelectItem>
                    <SelectItem value="4001_5000">R$ 4.001 a R$ 5.000</SelectItem>
                    <SelectItem value="acima_5000">Acima de R$ 5.000</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Link href={`/dashboard/alunos/${params.id}`}>
            <Button variant="outline" type="button">
              Cancelar
            </Button>
          </Link>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Salvando..." : "Salvar Alterações"}
          </Button>
        </div>
      </form>
    </div>
  )
}
