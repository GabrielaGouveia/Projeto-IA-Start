"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, AlertTriangle, Edit } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

export default function AlunoDetalhesPage({ params }: { params: { id: string } }) {
  // Simulando dados de um aluno específico
  const aluno = {
    id: params.id,
    nome: "Ana Silva",
    email: "ana.silva@exemplo.com",
    telefone: "(11) 98765-4321",
    telefoneSecundario: "(11) 3456-7890",
    endereco: "Rua das Flores, 123 - São Paulo, SP",
    dataNascimento: new Date("1995-05-15"),
    sexo: "feminino",
    naturalidade: "São Paulo",
    ufNaturalidade: "SP",
    raca: "parda",
    lgbt: false,
    deficiente: false,
    tipoDeficiencia: "",
    turma: "Desenvolvimento Web - Turma 3",
    curso: "Desenvolvimento Web Full Stack",
    risco: "baixo",
    dataCadastro: new Date("2023-01-15"),
    estudante: true,
    projeto: "Desenvolvimento Web Full Stack",
    codigoProjeto: "PROJ-2023",
    dataIngresso: new Date("2023-02-01"),
    dataSaida: null,
    unidade: "Unidade Centro",
    codigoUnidade: "UNID-001",
    bairro: "Centro",
    cidade: "São Paulo",
    uf: "SP",
    rendaPerCapta: 1200,
    conflitoLei: false,
    cadUnico: true,
    pessoasMoram: 3,
    pessoasTrabalham: 2,
    rendaPropria: 2000,
    rendaFamiliar: 4500,
    vulnerabilidadeSocial: "média",
    nivelEnsino: "superior",
    anoSerie: "3º ano",
    numeroFilhos: 0,
    dificuldadeLocomocao: "Nenhuma",
    interessesProfissionais: "Desenvolvimento web, mobile e inteligência artificial",
    objetivosCurtoPrazo: "Concluir o curso e conseguir um estágio na área",
    objetivosLongoPrazo: "Trabalhar como desenvolvedora full stack em uma empresa de tecnologia",
    experienciaAnterior: "Estágio de 6 meses como desenvolvedora front-end",
    habilidadesCompetencias: "HTML, CSS, JavaScript, React básico",
    nomeResponsavel1: "",
    telefoneResponsavel1: "",
    emailResponsavel1: "",
    parentescoResponsavel1: "",
    nomeResponsavel2: "",
    telefoneResponsavel2: "",
    emailResponsavel2: "",
    parentescoResponsavel2: "",
    motivoEscolhaCurso: "Interesse em desenvolvimento web e oportunidades de carreira na área",
    expectativasCurso: "Aprender tecnologias modernas e estar preparada para o mercado de trabalho",
    disponibilidadeHorario: "Período noturno e finais de semana",
    preferenciasAprendizagem: "Aulas práticas e projetos reais",
    recursosDigitais: "Computador próprio e acesso à internet",
    ultimoNivelEscolaridade: "superior_incompleto",
    instituicaoUltimoNivel: "Universidade de São Paulo",
    cursosAnteriores: "Curso básico de HTML e CSS",
    experienciaProfissionalArea: "Estágio como desenvolvedora front-end",
    tempoExperiencia: "6 meses",
    principaisAtividades: "Desenvolvimento de interfaces de usuário com HTML, CSS e JavaScript",
    interesseAreasEspecificas: "Front-end e UX/UI",
    possuiConexoes: true,
    detalhesConexoes: "Contatos em empresas de tecnologia através de networking em eventos",
    interesseMentoria: "mentorado",
    autoavaliacaoLideranca: "3",
    autoavaliacaoComunicacao: "4",
    autoavaliacaoTrabalhoEquipe: "4",
    outrasAutoavaliacoes: "Boa capacidade de aprendizado e adaptação",
    objetivosDesenvolvimentoPessoal: "Melhorar habilidades de comunicação e liderança",
    expectativasSalariais: "3001_4000",
    progresso: 65,
    alertas: [
      {
        id: "1",
        data: "10/09/2023",
        tipo: "Ausência",
        descricao: "Ausente por 3 aulas consecutivas",
        gravidade: "médio",
      },
      {
        id: "2",
        data: "25/08/2023",
        tipo: "Atividade",
        descricao: "Não entregou projeto final do módulo 2",
        gravidade: "alto",
      },
    ],
    feedbacks: [
      {
        id: "1",
        data: "15/09/2023",
        professor: "Roberto Almeida",
        conteudo: "Demonstrou melhora significativa no último projeto. Continue assim!",
      },
      {
        id: "2",
        data: "01/08/2023",
        professor: "Carla Mendes",
        conteudo: "Precisa melhorar a participação em sala e entregar as atividades no prazo.",
      },
    ],
  }

  const formatarData = (data: Date | null) => {
    if (!data) return "-"
    return format(data, "dd/MM/yyyy", { locale: ptBR })
  }

  const formatarValorMonetario = (valor: number) => {
    return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
  }

  const mapearNivelEscolaridade = (nivel: string) => {
    const mapeamento: Record<string, string> = {
      fundamental_incompleto: "Ensino Fundamental Incompleto",
      fundamental_completo: "Ensino Fundamental Completo",
      medio_incompleto: "Ensino Médio Incompleto",
      medio_completo: "Ensino Médio Completo",
      tecnico_incompleto: "Ensino Técnico Incompleto",
      tecnico_completo: "Ensino Técnico Completo",
      superior_incompleto: "Ensino Superior Incompleto",
      superior_completo: "Ensino Superior Completo",
      pos_graduacao: "Pós-Graduação",
      mestrado: "Mestrado",
      doutorado: "Doutorado",
    }
    return mapeamento[nivel] || nivel
  }

  const mapearExpectativaSalarial = (faixa: string) => {
    const mapeamento: Record<string, string> = {
      ate_1000: "Até R$ 1.000",
      10012000: "R$ 1.001 a R$ 2.000",
      20013000: "R$ 2.001 a R$ 3.000",
      30014000: "R$ 3.001 a R$ 4.000",
      40015000: "R$ 4.001 a R$ 5.000",
      acima_5000: "Acima de R$ 5.000",
    }
    return mapeamento[faixa] || faixa
  }

  const mapearInteresseMentoria = (interesse: string) => {
    const mapeamento: Record<string, string> = {
      mentor: "Mentor",
      mentorado: "Mentorado",
      nao: "Não tem interesse",
    }
    return mapeamento[interesse] || interesse
  }

  const calcularIdade = (dataNascimento: Date) => {
    const hoje = new Date()
    let idade = hoje.getFullYear() - dataNascimento.getFullYear()
    const m = hoje.getMonth() - dataNascimento.getMonth()

    if (m < 0 || (m === 0 && hoje.getDate() < dataNascimento.getDate())) {
      idade--
    }

    return idade
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/alunos">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Detalhes do Aluno</h1>
            <p className="text-muted-foreground">Visualize informações detalhadas do aluno.</p>
          </div>
        </div>
        <Link href={`/dashboard/alunos/${aluno.id}/editar`}>
          <Button>
            <Edit className="mr-2 h-4 w-4" />
            Editar
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="perfil" className="space-y-4">
        <TabsList>
          <TabsTrigger value="perfil">Perfil</TabsTrigger>
          <TabsTrigger value="academico">Acadêmico</TabsTrigger>
          <TabsTrigger value="socioeconomico">Socioeconômico</TabsTrigger>
          <TabsTrigger value="profissional">Profissional</TabsTrigger>
          <TabsTrigger value="alertas">Alertas e Feedbacks</TabsTrigger>
        </TabsList>

        {/* Aba de Perfil */}
        <TabsContent value="perfil" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Informações Pessoais */}
            <Card>
              <CardHeader>
                <CardTitle>Informações Pessoais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col items-center gap-2 mb-6">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={`https://avatar.vercel.sh/${aluno.id}.png`} alt={aluno.nome} />
                    <AvatarFallback>{aluno.nome.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-semibold">{aluno.nome}</h2>
                  <Badge
                    variant={
                      aluno.risco === "baixo" ? "outline" : aluno.risco === "médio" ? "secondary" : "destructive"
                    }
                  >
                    Risco {aluno.risco}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Data de Nascimento</p>
                    <p className="font-medium">{formatarData(aluno.dataNascimento)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Idade</p>
                    <p className="font-medium">{calcularIdade(aluno.dataNascimento)} anos</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Sexo</p>
                    <p className="font-medium">{aluno.sexo.charAt(0).toUpperCase() + aluno.sexo.slice(1)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Raça</p>
                    <p className="font-medium">{aluno.raca.charAt(0).toUpperCase() + aluno.raca.slice(1)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Naturalidade</p>
                    <p className="font-medium">{aluno.naturalidade || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">UF Naturalidade</p>
                    <p className="font-medium">{aluno.ufNaturalidade || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Grupo LGBT</p>
                    <p className="font-medium">{aluno.lgbt ? "Sim" : "Não"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Deficiente</p>
                    <p className="font-medium">{aluno.deficiente ? "Sim" : "Não"}</p>
                  </div>
                  {aluno.deficiente && (
                    <div className="col-span-2">
                      <p className="text-sm text-muted-foreground">Tipo de Deficiência</p>
                      <p className="font-medium">{aluno.tipoDeficiencia || "-"}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Informações de Contato */}
            <Card>
              <CardHeader>
                <CardTitle>Informações de Contato</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Telefone Principal</p>
                    <p className="font-medium">{aluno.telefone}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Telefone Secundário</p>
                    <p className="font-medium">{aluno.telefoneSecundario || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">E-mail</p>
                    <p className="font-medium">{aluno.email}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Localização */}
            <Card>
              <CardHeader>
                <CardTitle>Localização</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Bairro</p>
                    <p className="font-medium">{aluno.bairro}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Cidade</p>
                    <p className="font-medium">{aluno.cidade}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">UF</p>
                    <p className="font-medium">{aluno.uf}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações Específicas */}
            <Card>
              <CardHeader>
                <CardTitle>Informações Específicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Nível de Ensino</p>
                    <p className="font-medium">{aluno.nivelEnsino || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Ano/Série</p>
                    <p className="font-medium">{aluno.anoSerie || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Número de Filhos</p>
                    <p className="font-medium">{aluno.numeroFilhos}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Dificuldade de Locomoção</p>
                    <p className="font-medium">{aluno.dificuldadeLocomocao || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações de Contato dos Responsáveis (se menor de idade) */}
            {calcularIdade(aluno.dataNascimento) < 18 && (
              <Card>
                <CardHeader>
                  <CardTitle>Informações de Contato dos Responsáveis</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Nome do Responsável 1</p>
                      <p className="font-medium">{aluno.nomeResponsavel1 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Telefone do Responsável 1</p>
                      <p className="font-medium">{aluno.telefoneResponsavel1 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">E-mail do Responsável 1</p>
                      <p className="font-medium">{aluno.emailResponsavel1 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Grau de Parentesco do Responsável 1</p>
                      <p className="font-medium">{aluno.parentescoResponsavel1 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Nome do Responsável 2</p>
                      <p className="font-medium">{aluno.nomeResponsavel2 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Telefone do Responsável 2</p>
                      <p className="font-medium">{aluno.telefoneResponsavel2 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">E-mail do Responsável 2</p>
                      <p className="font-medium">{aluno.emailResponsavel2 || "-"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Grau de Parentesco do Responsável 2</p>
                      <p className="font-medium">{aluno.parentescoResponsavel2 || "-"}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Aba Acadêmica */}
        <TabsContent value="academico" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Informações de Cadastro e Participação */}
            <Card>
              <CardHeader>
                <CardTitle>Informações de Cadastro e Participação</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Data de Cadastro</p>
                    <p className="font-medium">{formatarData(aluno.dataCadastro)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Estudante</p>
                    <p className="font-medium">{aluno.estudante ? "Sim" : "Não"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Nome do Projeto</p>
                    <p className="font-medium">{aluno.projeto}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Código do Projeto</p>
                    <p className="font-medium">{aluno.codigoProjeto}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Data de Ingresso no Projeto</p>
                    <p className="font-medium">{formatarData(aluno.dataIngresso)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Data de Saída no Projeto</p>
                    <p className="font-medium">{formatarData(aluno.dataSaida)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Unidade</p>
                    <p className="font-medium">{aluno.unidade}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Código da Unidade</p>
                    <p className="font-medium">{aluno.codigoUnidade}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Histórico Educacional */}
            <Card>
              <CardHeader>
                <CardTitle>Histórico Educacional</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Último Nível de Escolaridade Concluído</p>
                    <p className="font-medium">{mapearNivelEscolaridade(aluno.ultimoNivelEscolaridade)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Instituição do Último Nível de Escolaridade</p>
                    <p className="font-medium">{aluno.instituicaoUltimoNivel || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Cursos Anteriores</p>
                    <p className="font-medium">{aluno.cursosAnteriores || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações sobre o Curso e Expectativas */}
            <Card>
              <CardHeader>
                <CardTitle>Informações sobre o Curso e Expectativas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Motivo da Escolha do Curso</p>
                    <p className="font-medium">{aluno.motivoEscolhaCurso || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Expectativas em Relação ao Curso</p>
                    <p className="font-medium">{aluno.expectativasCurso || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Disponibilidade de Horário para Estudo</p>
                    <p className="font-medium">{aluno.disponibilidadeHorario || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Preferências de Aprendizagem</p>
                    <p className="font-medium">{aluno.preferenciasAprendizagem || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Recursos Digitais Disponíveis</p>
                    <p className="font-medium">{aluno.recursosDigitais || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Progresso Acadêmico */}
            <Card>
              <CardHeader>
                <CardTitle>Progresso Acadêmico</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-muted-foreground">Progresso do curso</span>
                    <span className="text-sm font-medium">{aluno.progresso}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-[#2563EB] rounded-full" style={{ width: `${aluno.progresso}%` }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Aba Socioeconômica */}
        <TabsContent value="socioeconomico" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Informações Socioeconômicas */}
            <Card>
              <CardHeader>
                <CardTitle>Informações Socioeconômicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Renda Per Capita</p>
                    <p className="font-medium">{formatarValorMonetario(aluno.rendaPerCapta)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Conflito com a Lei</p>
                    <p className="font-medium">{aluno.conflitoLei ? "Sim" : "Não"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Possui Cad Único</p>
                    <p className="font-medium">{aluno.cadUnico ? "Sim" : "Não"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Pessoas que Moram na Residência</p>
                    <p className="font-medium">{aluno.pessoasMoram}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Pessoas que Trabalham na Residência</p>
                    <p className="font-medium">{aluno.pessoasTrabalham}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Renda Própria</p>
                    <p className="font-medium">{formatarValorMonetario(aluno.rendaPropria)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Renda Familiar</p>
                    <p className="font-medium">{formatarValorMonetario(aluno.rendaFamiliar)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Vulnerabilidade Social</p>
                    <p className="font-medium">
                      {aluno.vulnerabilidadeSocial.charAt(0).toUpperCase() + aluno.vulnerabilidadeSocial.slice(1)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Aba Profissional */}
        <TabsContent value="profissional" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Objetivos Profissionais */}
            <Card>
              <CardHeader>
                <CardTitle>Objetivos Profissionais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Interesses Profissionais</p>
                    <p className="font-medium">{aluno.interessesProfissionais || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Objetivos de Curto Prazo</p>
                    <p className="font-medium">{aluno.objetivosCurtoPrazo || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Objetivos de Longo Prazo</p>
                    <p className="font-medium">{aluno.objetivosLongoPrazo || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Experiência Profissional Anterior</p>
                    <p className="font-medium">{aluno.experienciaAnterior || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Habilidades e Competências</p>
                    <p className="font-medium">{aluno.habilidadesCompetencias || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Experiência Profissional */}
            <Card>
              <CardHeader>
                <CardTitle>Experiência Profissional</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Experiência Profissional na Área</p>
                    <p className="font-medium">{aluno.experienciaProfissionalArea || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Tempo de Experiência Profissional na Área</p>
                    <p className="font-medium">{aluno.tempoExperiencia || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Principais Atividades na Área Profissional</p>
                    <p className="font-medium">{aluno.principaisAtividades || "-"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Interesse em Áreas Específicas Dentro da Profissão</p>
                    <p className="font-medium">{aluno.interesseAreasEspecificas || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações de Rede e Mentoria */}
            <Card>
              <CardHeader>
                <CardTitle>Informações de Rede e Mentoria</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Possui Conexões Profissionais na Área</p>
                    <p className="font-medium">{aluno.possuiConexoes ? "Sim" : "Não"}</p>
                  </div>
                  {aluno.possuiConexoes && (
                    <div>
                      <p className="text-sm text-muted-foreground">Detalhes das Conexões Profissionais</p>
                      <p className="font-medium">{aluno.detalhesConexoes || "-"}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-muted-foreground">Interesse em Mentoria</p>
                    <p className="font-medium">{mapearInteresseMentoria(aluno.interesseMentoria)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações Comportamentais e de Desenvolvimento Pessoal */}
            <Card>
              <CardHeader>
                <CardTitle>Desenvolvimento Pessoal</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Autoavaliação: Liderança</p>
                    <p className="font-medium">{aluno.autoavaliacaoLideranca}/5</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Autoavaliação: Comunicação</p>
                    <p className="font-medium">{aluno.autoavaliacaoComunicacao}/5</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Autoavaliação: Trabalho em Equipe</p>
                    <p className="font-medium">{aluno.autoavaliacaoTrabalhoEquipe}/5</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Expectativas Salariais</p>
                    <p className="font-medium">{mapearExpectativaSalarial(aluno.expectativasSalariais)}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Outras Autoavaliações de Habilidades</p>
                    <p className="font-medium">{aluno.outrasAutoavaliacoes || "-"}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Objetivos de Desenvolvimento Pessoal</p>
                    <p className="font-medium">{aluno.objetivosDesenvolvimentoPessoal || "-"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Aba de Alertas e Feedbacks */}
        <TabsContent value="alertas" className="space-y-4">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Alertas */}
            <Card>
              <CardHeader>
                <CardTitle>Histórico de Alertas</CardTitle>
                <CardDescription>Alertas de risco gerados para este aluno.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aluno.alertas.map((alerta) => (
                    <div key={alerta.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <AlertTriangle
                            className={`h-5 w-5 ${
                              alerta.gravidade === "alto"
                                ? "text-red-500"
                                : alerta.gravidade === "médio"
                                  ? "text-amber-500"
                                  : "text-blue-500"
                            }`}
                          />
                          <span className="font-medium">{alerta.tipo}</span>
                        </div>
                        <Badge
                          variant={
                            alerta.gravidade === "baixo"
                              ? "outline"
                              : alerta.gravidade === "médio"
                                ? "secondary"
                                : "destructive"
                          }
                        >
                          {alerta.gravidade}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">{alerta.data}</p>
                      <p>{alerta.descricao}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Feedbacks */}
            <Card>
              <CardHeader>
                <CardTitle>Feedbacks dos Professores</CardTitle>
                <CardDescription>Avaliações e comentários dos professores.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aluno.feedbacks.map((feedback) => (
                    <div key={feedback.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{feedback.professor}</span>
                        <span className="text-sm text-muted-foreground">{feedback.data}</span>
                      </div>
                      <p>{feedback.conteudo}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
