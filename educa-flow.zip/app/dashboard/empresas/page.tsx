import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus } from "lucide-react"
import Link from "next/link"

const empresas = [
  {
    id: "1",
    nome: "TechSolutions Ltda",
    cnpj: "12.345.678/0001-90",
    contato: "contato@techsolutions.com",
    telefone: "(11) 3456-7890",
    turmas: 2,
    alunos: 35,
    status: "ativo",
  },
  {
    id: "2",
    nome: "DataInova S.A.",
    cnpj: "23.456.789/0001-01",
    contato: "contato@datainova.com",
    telefone: "(11) 4567-8901",
    turmas: 1,
    alunos: 22,
    status: "ativo",
  },
  {
    id: "3",
    nome: "WebDev Brasil",
    cnpj: "34.567.890/0001-12",
    contato: "contato@webdevbrasil.com",
    telefone: "(11) 5678-9012",
    turmas: 3,
    alunos: 48,
    status: "ativo",
  },
  {
    id: "4",
    nome: "CloudTech Sistemas",
    cnpj: "45.678.901/0001-23",
    contato: "contato@cloudtech.com",
    telefone: "(11) 6789-0123",
    turmas: 1,
    alunos: 15,
    status: "ativo",
  },
]

export default function EmpresasPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gerenciamento de Empresas</h1>
          <p className="text-muted-foreground">Gerencie todas as empresas parceiras da plataforma.</p>
        </div>
        <Link href="/dashboard/empresas/nova">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Adicionar Empresa
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 flex-1">
          <Input placeholder="Buscar empresas..." />
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>CNPJ</TableHead>
              <TableHead>Contato</TableHead>
              <TableHead>Telefone</TableHead>
              <TableHead>Turmas</TableHead>
              <TableHead>Alunos</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {empresas.map((empresa) => (
              <TableRow key={empresa.id}>
                <TableCell className="font-medium">{empresa.nome}</TableCell>
                <TableCell>{empresa.cnpj}</TableCell>
                <TableCell>{empresa.contato}</TableCell>
                <TableCell>{empresa.telefone}</TableCell>
                <TableCell>{empresa.turmas}</TableCell>
                <TableCell>{empresa.alunos}</TableCell>
                <TableCell>
                  <Badge variant="outline">{empresa.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Link href={`/dashboard/empresas/${empresa.id}`}>
                    <Button variant="ghost" size="sm">
                      Ver detalhes
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
