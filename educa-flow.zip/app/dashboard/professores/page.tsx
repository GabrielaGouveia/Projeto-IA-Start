import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus } from "lucide-react"
import Link from "next/link"

const professores = [
  {
    id: "1",
    nome: "Roberto Almeida",
    email: "roberto.almeida@educaflow.com",
    telefone: "(11) 98765-4321",
    especialidade: "Desenvolvimento Web",
    turmas: 2,
    alunos: 56,
    status: "ativo",
  },
  {
    id: "2",
    nome: "Carla Mendes",
    email: "carla.mendes@educaflow.com",
    telefone: "(11) 97654-3210",
    especialidade: "Ciência de Dados",
    turmas: 1,
    alunos: 22,
    status: "ativo",
  },
  {
    id: "3",
    nome: "Paulo Ribeiro",
    email: "paulo.ribeiro@educaflow.com",
    telefone: "(11) 96543-2109",
    especialidade: "UX/UI Design",
    turmas: 2,
    alunos: 35,
    status: "ativo",
  },
  {
    id: "4",
    nome: "Marcelo Santos",
    email: "marcelo.santos@educaflow.com",
    telefone: "(11) 95432-1098",
    especialidade: "DevOps & Cloud",
    turmas: 1,
    alunos: 15,
    status: "ativo",
  },
  {
    id: "5",
    nome: "Juliana Costa",
    email: "juliana.costa@educaflow.com",
    telefone: "(11) 94321-0987",
    especialidade: "Desenvolvimento Mobile",
    turmas: 4,
    alunos: 98,
    status: "ativo",
  },
]

export default function ProfessoresPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gerenciamento de Professores</h1>
          <p className="text-muted-foreground">Gerencie todos os professores da plataforma.</p>
        </div>
        <Link href="/dashboard/professores/novo">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Adicionar Professor
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 flex-1">
          <Input placeholder="Buscar professores..." />
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Telefone</TableHead>
              <TableHead>Especialidade</TableHead>
              <TableHead>Turmas</TableHead>
              <TableHead>Alunos</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {professores.map((professor) => (
              <TableRow key={professor.id}>
                <TableCell className="font-medium">{professor.nome}</TableCell>
                <TableCell>{professor.email}</TableCell>
                <TableCell>{professor.telefone}</TableCell>
                <TableCell>{professor.especialidade}</TableCell>
                <TableCell>{professor.turmas}</TableCell>
                <TableCell>{professor.alunos}</TableCell>
                <TableCell>
                  <Badge variant="outline">{professor.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Link href={`/dashboard/professores/${professor.id}`}>
                    <Button variant="ghost" size="sm">
                      Ver detalhes
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
