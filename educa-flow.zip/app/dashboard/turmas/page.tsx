import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus } from "lucide-react"
import Link from "next/link"

const turmas = [
  {
    id: "1",
    nome: "Desenvolvimento Web - Turma 3",
    curso: "Desenvolvimento Web Full Stack",
    professor: "Roberto Almeida",
    inicio: "01/02/2023",
    fim: "01/12/2023",
    status: "em andamento",
    alunos: 28,
  },
  {
    id: "2",
    nome: "Data Science - Turma 1",
    curso: "Ciência de Dados",
    professor: "Carla Mendes",
    inicio: "15/03/2023",
    fim: "15/01/2024",
    status: "em andamento",
    alunos: 22,
  },
  {
    id: "3",
    nome: "UX/UI - Turma 2",
    curso: "Design de Experiência do Usuário",
    professor: "Paulo Ribeiro",
    inicio: "10/01/2023",
    fim: "10/11/2023",
    status: "em andamento",
    alunos: 18,
  },
  {
    id: "4",
    nome: "DevOps - Turma 1",
    curso: "DevOps & Cloud",
    professor: "Marcelo Santos",
    inicio: "05/04/2023",
    fim: "05/02/2024",
    status: "em andamento",
    alunos: 15,
  },
  {
    id: "5",
    nome: "Mobile - Turma 4",
    curso: "Desenvolvimento Mobile",
    professor: "Juliana Costa",
    inicio: "20/02/2023",
    fim: "20/12/2023",
    status: "em andamento",
    alunos: 25,
  },
]

export default function TurmasPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Gerenciamento de Turmas</h1>
          <p className="text-muted-foreground">Gerencie todas as turmas da plataforma.</p>
        </div>
        <Link href="/dashboard/turmas/nova">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Criar Turma
          </Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="grid gap-2 flex-1">
          <Input placeholder="Buscar turmas..." />
        </div>
        <div className="grid gap-2 w-full md:w-[180px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Curso" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Cursos</SelectItem>
              <SelectItem value="web">Desenvolvimento Web Full Stack</SelectItem>
              <SelectItem value="data">Ciência de Dados</SelectItem>
              <SelectItem value="ux">Design de Experiência do Usuário</SelectItem>
              <SelectItem value="devops">DevOps & Cloud</SelectItem>
              <SelectItem value="mobile">Desenvolvimento Mobile</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2 w-full md:w-[180px]">
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Professor" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os Professores</SelectItem>
              <SelectItem value="roberto">Roberto Almeida</SelectItem>
              <SelectItem value="carla">Carla Mendes</SelectItem>
              <SelectItem value="paulo">Paulo Ribeiro</SelectItem>
              <SelectItem value="marcelo">Marcelo Santos</SelectItem>
              <SelectItem value="juliana">Juliana Costa</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Curso</TableHead>
              <TableHead>Professor</TableHead>
              <TableHead>Início</TableHead>
              <TableHead>Término</TableHead>
              <TableHead>Alunos</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {turmas.map((turma) => (
              <TableRow key={turma.id}>
                <TableCell className="font-medium">{turma.nome}</TableCell>
                <TableCell>{turma.curso}</TableCell>
                <TableCell>{turma.professor}</TableCell>
                <TableCell>{turma.inicio}</TableCell>
                <TableCell>{turma.fim}</TableCell>
                <TableCell>{turma.alunos}</TableCell>
                <TableCell>
                  <Badge variant="secondary">{turma.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Link href={`/dashboard/turmas/${turma.id}`}>
                    <Button variant="ghost" size="sm">
                      Ver detalhes
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
