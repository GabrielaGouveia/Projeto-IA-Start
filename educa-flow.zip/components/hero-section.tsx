import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="space-y-4">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#1E3A8A]">
              Educa Flow: Plataforma Inteligente de Gestão Educacional
            </h1>
            <p className="max-w-[600px] text-[#4B5563] md:text-xl">
              Capacitando o sucesso dos seus alunos com inteligência artificial e gestão eficiente
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/perfil">
                <Button className="bg-[#2563EB] hover:bg-[#1E40AF] text-white">Experimente Agora</Button>
              </Link>
              <Link href="/perfil">
                <Button variant="outline" className="border-[#2563EB] text-[#2563EB]">
                  Para Empresas Parceiras
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex justify-center">
            <div className="relative w-full max-w-[600px] aspect-square">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Educa%20flow-5u5gvmGt5zr5hWbqTSGQo4LT7Win5k.png"
                alt="Educa Flow - Plataforma de gestão educacional com IA"
                fill
                className="object-contain"
                priority
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
