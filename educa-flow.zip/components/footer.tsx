import Link from "next/link"

export function Footer() {
  return (
    <footer className="w-full py-6 bg-white border-t">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-sm text-[#6B7280]">
            © {new Date().getFullYear()} Educa Flow. Todos os direitos reservados.
          </p>
          <nav className="flex gap-4 sm:gap-6">
            <Link href="#" className="text-sm text-[#6B7280] hover:underline underline-offset-4">
              Termos de Uso
            </Link>
            <Link href="#" className="text-sm text-[#6B7280] hover:underline underline-offset-4">
              Política de Privacidade
            </Link>
            <Link href="#" className="text-sm text-[#6B7280] hover:underline underline-offset-4">
              Contato
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  )
}
