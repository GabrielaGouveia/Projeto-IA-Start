import { Brain, MessageSquare, ShieldCheck } from "lucide-react"

export function BenefitsSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-[#1E3A8A] mb-12">
            Nossos Principais Benefícios
          </h2>
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm transition-all hover:shadow-md">
              <div className="rounded-full bg-purple-100 p-3">
                <Brain className="h-6 w-6 text-[#7C3AED]" />
              </div>
              <h3 className="text-xl font-bold text-[#1E3A8A]">Identificação Inteligente de Riscos</h3>
              <p className="text-[#4B5563]">Use IA para identificar alunos em risco de evasão e agir proativamente.</p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm transition-all hover:shadow-md">
              <div className="rounded-full bg-green-100 p-3">
                <MessageSquare className="h-6 w-6 text-[#10B981]" />
              </div>
              <h3 className="text-xl font-bold text-[#1E3A8A]">Comunicação Estruturada</h3>
              <p className="text-[#4B5563]">Ferramentas para professores darem feedback eficaz.</p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm transition-all hover:shadow-md">
              <div className="rounded-full bg-orange-100 p-3">
                <ShieldCheck className="h-6 w-6 text-[#F59E0B]" />
              </div>
              <h3 className="text-xl font-bold text-[#1E3A8A]">Experiências Personalizadas</h3>
              <p className="text-[#4B5563]">Painéis por perfil e controle granular de acesso.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
