import { Button } from "@/components/ui/button"
import Link from "next/link"
import { LogIn } from "lucide-react"

export function Navbar() {
  return (
    <header className="w-full py-4 bg-white border-b">
      <div className="container px-4 md:px-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-[#1E3A8A]">Educa Flow</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/perfil">
              <Button className="bg-[#2563EB] hover:bg-[#1E40AF] text-white">
                <LogIn className="mr-2 h-4 w-4" />
                Entrar
              </Button>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}
