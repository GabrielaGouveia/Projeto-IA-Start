import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export function PartnerSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="space-y-4">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-[#1E3A8A]">
              Torne-se um Parceiro Educa Flow
            </h2>
            <p className="text-[#4B5563] md:text-xl">
              Conecte sua empresa com talentos em desenvolvimento e contribua para a educação.
            </p>
          </div>
          <div className="space-y-6">
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Check className="h-5 w-5 text-[#2563EB]" />
                <span className="text-[#4B5563]">Acesso a métricas de engajamento</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-5 w-5 text-[#2563EB]" />
                <span className="text-[#4B5563]">Identificação de futuros talentos</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-5 w-5 text-[#2563EB]" />
                <span className="text-[#4B5563]">Impacto comunitário</span>
              </li>
            </ul>
            <Button className="bg-gradient-to-r from-[#2563EB] to-[#1E40AF] text-white">Saiba Mais</Button>
          </div>
        </div>
      </div>
    </section>
  )
}
