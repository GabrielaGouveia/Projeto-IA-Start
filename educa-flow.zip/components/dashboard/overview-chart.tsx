"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const data = [
  { name: "Jan", taxa: 5.2 },
  { name: "Fev", taxa: 4.8 },
  { name: "Mar", taxa: 5.5 },
  { name: "Abr", taxa: 5.7 },
  { name: "Mai", taxa: 4.9 },
  { name: "Jun", taxa: 4.2 },
  { name: "Jul", taxa: 3.8 },
  { name: "Ago", taxa: 3.5 },
  { name: "Set", taxa: 3.2 },
  { name: "Out", taxa: 3.0 },
  { name: "Nov", taxa: 2.8 },
  { name: "Dez", taxa: 2.5 },
]

export function OverviewChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="taxa" stroke="#2563EB" activeDot={{ r: 8 }} name="Taxa de Evasão (%)" />
      </LineChart>
    </ResponsiveContainer>
  )
}
