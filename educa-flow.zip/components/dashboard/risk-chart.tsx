"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const data = [
  { name: "Desenvolvimento Web", risco: 12 },
  { name: "Data Science", risco: 8 },
  { name: "UX/UI Design", risco: 5 },
  { name: "DevOps", risco: 7 },
  { name: "Mobile", risco: 10 },
]

export function RiskChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="risco" fill="#F59E0B" name="Alunos em Risco" />
      </BarChart>
    </ResponsiveContainer>
  )
}
