"use client"

import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  ResponsiveContainer,
  Tooltip,
} from "recharts"

const data = [
  { subject: "Participação", A: 4.2, B: 3.8, fullMark: 5 },
  { subject: "Proatividade", A: 3.8, B: 3.5, fullMark: 5 },
  { subject: "Colaboração", A: 4.5, B: 4.0, fullMark: 5 },
  { subject: "Comunicação", A: 3.9, B: 3.7, fullMark: 5 },
  { subject: "Resolução", A: 4.0, B: 3.6, fullMark: 5 },
  { subject: "Comprometimento", A: 4.3, B: 3.9, fullMark: 5 },
]

export function EngajamentoRadarChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey="subject" />
        <PolarRadiusAxis angle={30} domain={[0, 5]} />
        <Radar name="Turmas Atuais" dataKey="A" stroke="#2563EB" fill="#2563EB" fillOpacity={0.6} />
        <Radar name="Média Histórica" dataKey="B" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.6} />
        <Tooltip />
        <Legend />
      </RadarChart>
    </ResponsiveContainer>
  )
}
