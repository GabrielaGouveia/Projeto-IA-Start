"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const data = [
  { name: "Ana S.", engajamento: 4.2 },
  { name: "Carlos O.", engajamento: 3.8 },
  { name: "Mariana S.", engajamento: 4.5 },
  { name: "Pedro C.", engajamento: 3.3 },
  { name: "Juliana L.", engajamento: 4.5 },
  { name: "Rafael M.", engajamento: 3.9 },
  { name: "Fernanda R.", engajamento: 4.1 },
  { name: "Bruno A.", engajamento: 3.7 },
]

export function EngajamentoBarChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis domain={[0, 5]} />
        <Tooltip formatter={(value) => [value, "Média de Engajamento"]} />
        <Legend />
        <Bar dataKey="engajamento" fill="#2563EB" name="Média de Engajamento (1-5)" />
      </BarChart>
    </ResponsiveContainer>
  )
}
