"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const data = [
  { name: "Dev Web - T3", conclusao: 92 },
  { name: "Dev Web - T4", conclusao: 85 },
  { name: "Mobile - T2", conclusao: 78 },
  { name: "Data Science - T1", conclusao: 95 },
  { name: "UX/UI - T2", conclusao: 88 },
]

export function TaxaConclusaoChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis domain={[0, 100]} />
        <Tooltip formatter={(value) => [`${value}%`, "Taxa de Conclusão"]} />
        <Legend />
        <Bar dataKey="conclusao" fill="#2563EB" name="Taxa de Conclusão (%)" />
      </BarChart>
    </ResponsiveContainer>
  )
}
