"use client"

import { useNotifications } from "@/contexts/notification-context"
import { NotificationBell } from "@/components/notifications/notification-bell"

export function ParceiroHeader() {
  const { notifications, markAsRead } = useNotifications()

  const handleMarkAsRead = (id: string) => {
    markAsRead(id)
  }

  return (
    <header className="bg-white border-b px-4 py-2 flex items-center justify-end">
      <div className="flex items-center gap-2">
        <NotificationBell notifications={notifications} userType="parceiro" onMarkAsRead={handleMarkAsRead} />
      </div>
    </header>
  )
}
