"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useNotifications } from "@/contexts/notification-context"
import { AlertTriangle } from "lucide-react"

// Dados simulados de alunos
const alunos = [
  { id: "1", nome: "Ana Silva", turma: "Desenvolvimento Web - Turma 3" },
  { id: "2", nome: "Carlos Oliveira", turma: "Desenvolvimento Web - Turma 4" },
  { id: "3", nome: "Mariana Santos", turma: "Desenvolvimento Web - Turma 3" },
  { id: "4", nome: "Pedro Costa", turma: "Mobile - Turma 2" },
  { id: "5", nome: "Juliana Lima", turma: "Mobile - Turma 2" },
]

// Tipos de alertas
const tiposAlerta = [
  { id: "ausencia", nome: "Alerta de Ausência" },
  { id: "desempenho", nome: "Alerta de Desempenho" },
  { id: "engajamento", nome: "Alerta de Engajamento" },
]

export function AIAlertSimulator() {
  const [alunoSelecionado, setAlunoSelecionado] = useState<string>("")
  const [tipoAlertaSelecionado, setTipoAlertaSelecionado] = useState<string>("")
  const { addNotification } = useNotifications()

  const handleGerarAlerta = () => {
    if (!alunoSelecionado || !tipoAlertaSelecionado) return

    const aluno = alunos.find((a) => a.id === alunoSelecionado)
    if (!aluno) return

    let mensagem = ""
    let titulo = ""

    switch (tipoAlertaSelecionado) {
      case "ausencia":
        titulo = "Alerta de Ausência"
        mensagem = `O aluno ${aluno.nome} está ausente há 3 aulas consecutivas.`
        break
      case "desempenho":
        titulo = "Alerta de Desempenho"
        mensagem = `O aluno ${aluno.nome} apresentou baixo desempenho nas últimas avaliações.`
        break
      case "engajamento":
        titulo = "Alerta de Engajamento"
        mensagem = `O aluno ${aluno.nome} demonstrou baixo engajamento nas atividades recentes.`
        break
    }

    addNotification({
      title: titulo,
      message: mensagem,
      type: "alerta",
      aluno: {
        id: aluno.id,
        nome: aluno.nome,
        turma: aluno.turma,
      },
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          Simulador de Alertas da IA
        </CardTitle>
        <CardDescription>Use esta ferramenta para simular alertas gerados pela IA para demonstração.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Selecione um aluno</label>
          <Select value={alunoSelecionado} onValueChange={setAlunoSelecionado}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um aluno" />
            </SelectTrigger>
            <SelectContent>
              {alunos.map((aluno) => (
                <SelectItem key={aluno.id} value={aluno.id}>
                  {aluno.nome} - {aluno.turma}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Tipo de alerta</label>
          <Select value={tipoAlertaSelecionado} onValueChange={setTipoAlertaSelecionado}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o tipo de alerta" />
            </SelectTrigger>
            <SelectContent>
              {tiposAlerta.map((tipo) => (
                <SelectItem key={tipo.id} value={tipo.id}>
                  {tipo.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleGerarAlerta} disabled={!alunoSelecionado || !tipoAlertaSelecionado} className="w-full">
          Gerar Alerta
        </Button>
      </CardFooter>
    </Card>
  )
}
