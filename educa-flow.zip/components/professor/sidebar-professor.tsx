"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Users, History, LogOut, School, LayoutDashboard } from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  {
    title: "Painel",
    href: "/professor/painel",
    icon: LayoutDashboard,
  },
  {
    title: "Minhas Turmas",
    href: "/professor/turmas",
    icon: School,
  },
  {
    title: "Lista de Alunos",
    href: "/professor/alunos",
    icon: Users,
  },
  {
    title: "Histórico",
    href: "/professor/historico",
    icon: History,
  },
]

export function SidebarProfessor() {
  const pathname = usePathname()

  return (
    <div className="hidden md:flex flex-col w-64 bg-slate-900 text-white">
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold text-[#2563EB]">Educa Flow</span>
        </div>
        <div className="text-sm text-slate-400 mt-1">Painel do Professor</div>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-md transition-colors",
              pathname === item.href ? "bg-[#2563EB] text-white" : "text-slate-300 hover:bg-slate-800 hover:text-white",
            )}
          >
            <item.icon className="h-5 w-5" />
            <span>{item.title}</span>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-700">
        <Link
          href="/"
          className="flex items-center gap-3 px-3 py-2 rounded-md text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <LogOut className="h-5 w-5" />
          <span>Sair</span>
        </Link>
      </div>
    </div>
  )
}
