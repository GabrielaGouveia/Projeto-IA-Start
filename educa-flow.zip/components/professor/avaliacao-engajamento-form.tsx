"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { School, Send } from "lucide-react"

// Dados simulados de turmas
const turmas = [
  { id: "1", nome: "Desenvolvimento Web - Turma 3" },
  { id: "2", nome: "Desenvolvimento Web - Turma 4" },
  { id: "3", nome: "Mobile - Turma 2" },
]

export function AvaliacaoEngajamentoForm() {
  const [turmaSelecionada, setTurmaSelecionada] = useState<string>("")
  const [participacao, setParticipacao] = useState<number[]>([3])
  const [proatividade, setProatividade] = useState<number[]>([3])
  const [colaboracao, setColaboracao] = useState<number[]>([3])
  const [comunicacao, setComunicacao] = useState<number[]>([3])
  const [comentarios, setComentarios] = useState<string>("")
  const [enviando, setEnviando] = useState<boolean>(false)
  const [enviado, setEnviado] = useState<boolean>(false)

  const handleSubmit = () => {
    if (!turmaSelecionada) return

    setEnviando(true)

    // Simular envio
    setTimeout(() => {
      setEnviando(false)
      setEnviado(true)

      // Simular notificação para a empresa parceira
      const turma = turmas.find((t) => t.id === turmaSelecionada)
      if (turma) {
        const parceiroNotifications = localStorage.getItem("notifications_parceiro")
        let parceiroNotificationsList = []

        try {
          parceiroNotificationsList = parceiroNotifications ? JSON.parse(parceiroNotifications) : []
        } catch (error) {
          console.error("Erro ao carregar notificações do parceiro:", error)
        }

        const newNotification = {
          id: Date.now().toString(),
          title: "Avaliação de Engajamento Concluída",
          message: `A avaliação de engajamento da turma '${turma.nome}' foi concluída pelo professor.`,
          type: "avaliacao",
          date: new Date().toISOString(),
          read: false,
        }

        parceiroNotificationsList = [newNotification, ...parceiroNotificationsList]
        localStorage.setItem("notifications_parceiro", JSON.stringify(parceiroNotificationsList))
      }

      // Resetar formulário após 2 segundos
      setTimeout(() => {
        setTurmaSelecionada("")
        setParticipacao([3])
        setProatividade([3])
        setColaboracao([3])
        setComunicacao([3])
        setComentarios("")
        setEnviado(false)
      }, 2000)
    }, 1500)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <School className="h-5 w-5 text-blue-500" />
          Avaliação de Engajamento
        </CardTitle>
        <CardDescription>
          Preencha este formulário para enviar uma avaliação de engajamento da turma para a empresa parceira.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Selecione uma turma</Label>
          <Select value={turmaSelecionada} onValueChange={setTurmaSelecionada} disabled={enviando || enviado}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione uma turma" />
            </SelectTrigger>
            <SelectContent>
              {turmas.map((turma) => (
                <SelectItem key={turma.id} value={turma.id}>
                  {turma.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Participação Ativa</Label>
              <span className="text-sm">{participacao[0]}/5</span>
            </div>
            <Slider
              value={participacao}
              onValueChange={setParticipacao}
              min={1}
              max={5}
              step={1}
              disabled={enviando || enviado}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Proatividade</Label>
              <span className="text-sm">{proatividade[0]}/5</span>
            </div>
            <Slider
              value={proatividade}
              onValueChange={setProatividade}
              min={1}
              max={5}
              step={1}
              disabled={enviando || enviado}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Colaboração</Label>
              <span className="text-sm">{colaboracao[0]}/5</span>
            </div>
            <Slider
              value={colaboracao}
              onValueChange={setColaboracao}
              min={1}
              max={5}
              step={1}
              disabled={enviando || enviado}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label>Comunicação</Label>
              <span className="text-sm">{comunicacao[0]}/5</span>
            </div>
            <Slider
              value={comunicacao}
              onValueChange={setComunicacao}
              min={1}
              max={5}
              step={1}
              disabled={enviando || enviado}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Comentários Adicionais</Label>
          <Textarea
            placeholder="Adicione comentários sobre o engajamento da turma..."
            value={comentarios}
            onChange={(e) => setComentarios(e.target.value)}
            disabled={enviando || enviado}
          />
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSubmit} disabled={!turmaSelecionada || enviando || enviado} className="w-full">
          {enviando ? (
            "Enviando..."
          ) : enviado ? (
            <>
              <Send className="mr-2 h-4 w-4" />
              Enviado com Sucesso!
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Enviar Avaliação
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
