"use client"

import { useState } from "react"
import { Bell } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { NotificationList } from "@/components/notifications/notification-list"
import type { NotificationType } from "@/types/notifications"

interface NotificationBellProps {
  notifications: NotificationType[]
  userType: "professor" | "gerencia" | "parceiro"
  onMarkAsRead?: (id: string) => void
  onAddComment?: (id: string, comment: string) => void
  onForward?: (id: string, comment: string) => void
}

export function NotificationBell({
  notifications,
  userType,
  onMarkAsRead,
  onAddComment,
  onForward,
}: NotificationBellProps) {
  const [open, setOpen] = useState(false)

  const unreadCount = notifications.filter((notification) => !notification.read).length

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen)
  }

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <Badge
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-red-500"
              variant="destructive"
            >
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="p-2 border-b">
          <h3 className="font-medium">Notificações</h3>
        </div>
        <NotificationList
          notifications={notifications}
          userType={userType}
          onMarkAsRead={onMarkAsRead}
          onAddComment={onAddComment}
          onForward={onForward}
        />
      </PopoverContent>
    </Popover>
  )
}
