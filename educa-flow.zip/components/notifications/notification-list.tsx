"use client"

import { useState } from "react"
import { Forward, MessageSquare, AlertTriangle, User, Clock, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import type { NotificationType } from "@/types/notifications"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface NotificationListProps {
  notifications: NotificationType[]
  userType: "professor" | "gerencia" | "parceiro"
  onMarkAsRead?: (id: string) => void
  onAddComment?: (id: string, comment: string) => void
  onForward?: (id: string, comment: string) => void
}

export function NotificationList({
  notifications,
  userType,
  onMarkAsRead,
  onAddComment,
  onForward,
}: NotificationListProps) {
  const [commentText, setCommentText] = useState<Record<string, string>>({})
  const [expandedNotification, setExpandedNotification] = useState<string | null>(null)
  const [commentMode, setCommentMode] = useState<Record<string, boolean>>({})
  const [forwardMode, setForwardMode] = useState<Record<string, boolean>>({})

  const handleToggleExpand = (id: string) => {
    setExpandedNotification(expandedNotification === id ? null : id)

    // Marcar como lida quando expandir
    if (!notifications.find((n) => n.id === id)?.read && onMarkAsRead) {
      onMarkAsRead(id)
    }
  }

  const handleToggleCommentMode = (id: string) => {
    setCommentMode((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
    setForwardMode((prev) => ({
      ...prev,
      [id]: false,
    }))
  }

  const handleToggleForwardMode = (id: string) => {
    setForwardMode((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
    setCommentMode((prev) => ({
      ...prev,
      [id]: false,
    }))
  }

  const handleCommentChange = (id: string, value: string) => {
    setCommentText((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleAddComment = (id: string) => {
    if (onAddComment && commentText[id]?.trim()) {
      onAddComment(id, commentText[id])
      setCommentText((prev) => ({
        ...prev,
        [id]: "",
      }))
      setCommentMode((prev) => ({
        ...prev,
        [id]: false,
      }))
    }
  }

  const handleForward = (id: string) => {
    if (onForward && commentText[id]?.trim()) {
      onForward(id, commentText[id])
      setCommentText((prev) => ({
        ...prev,
        [id]: "",
      }))
      setForwardMode((prev) => ({
        ...prev,
        [id]: false,
      }))
    }
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "alerta":
        return <AlertTriangle className="h-5 w-5 text-amber-500" />
      case "comentario":
        return <MessageSquare className="h-5 w-5 text-blue-500" />
      case "avaliacao":
        return <User className="h-5 w-5 text-green-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }

  if (notifications.length === 0) {
    return <div className="p-4 text-center text-muted-foreground">Nenhuma notificação no momento.</div>
  }

  return (
    <div className="max-h-[400px] overflow-y-auto">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={cn(
            "border-b last:border-b-0 p-3 cursor-pointer transition-colors",
            notification.read ? "bg-white" : "bg-slate-50",
            expandedNotification === notification.id ? "bg-slate-100" : "",
          )}
        >
          <div className="flex items-start gap-3" onClick={() => handleToggleExpand(notification.id)}>
            <div className="mt-0.5">{getNotificationIcon(notification.type)}</div>
            <div className="flex-1 min-w-0">
              <p className={cn("text-sm", !notification.read && "font-medium")}>{notification.title}</p>
              <p className="text-xs text-muted-foreground line-clamp-2">{notification.message}</p>
              <div className="flex items-center gap-1 mt-1">
                <Clock className="h-3 w-3 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  {format(new Date(notification.date), "dd MMM, HH:mm", { locale: ptBR })}
                </span>
              </div>
            </div>
            {!notification.read && <div className="h-2 w-2 rounded-full bg-blue-500 mt-1"></div>}
          </div>

          {expandedNotification === notification.id && (
            <div className="mt-2 pl-8">
              {notification.comments && notification.comments.length > 0 && (
                <div className="mb-2 space-y-2">
                  {notification.comments.map((comment, index) => (
                    <div key={index} className="bg-slate-100 p-2 rounded-md text-sm">
                      <p className="text-xs font-medium">{comment.author}:</p>
                      <p className="text-sm">{comment.text}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(comment.date), "dd MMM, HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* Ações específicas para o perfil de professor */}
              {userType === "professor" && !notification.forwarded && (
                <div className="flex gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleToggleCommentMode(notification.id)
                    }}
                  >
                    <MessageSquare className="h-4 w-4 mr-1" />
                    Comentar
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleToggleForwardMode(notification.id)
                    }}
                  >
                    <Forward className="h-4 w-4 mr-1" />
                    Encaminhar
                  </Button>
                </div>
              )}

              {/* Modo de comentário */}
              {commentMode[notification.id] && (
                <div className="mt-2" onClick={(e) => e.stopPropagation()}>
                  <Textarea
                    placeholder="Adicione um comentário..."
                    className="min-h-[80px] text-sm"
                    value={commentText[notification.id] || ""}
                    onChange={(e) => handleCommentChange(notification.id, e.target.value)}
                  />
                  <div className="flex justify-end gap-2 mt-2">
                    <Button variant="outline" size="sm" onClick={() => handleToggleCommentMode(notification.id)}>
                      Cancelar
                    </Button>
                    <Button size="sm" onClick={() => handleAddComment(notification.id)}>
                      Adicionar
                    </Button>
                  </div>
                </div>
              )}

              {/* Modo de encaminhamento */}
              {forwardMode[notification.id] && (
                <div className="mt-2" onClick={(e) => e.stopPropagation()}>
                  <Textarea
                    placeholder="Adicione um comentário para encaminhar à gerência..."
                    className="min-h-[80px] text-sm"
                    value={commentText[notification.id] || ""}
                    onChange={(e) => handleCommentChange(notification.id, e.target.value)}
                  />
                  <div className="flex justify-end gap-2 mt-2">
                    <Button variant="outline" size="sm" onClick={() => handleToggleForwardMode(notification.id)}>
                      Cancelar
                    </Button>
                    <Button size="sm" onClick={() => handleForward(notification.id)}>
                      Encaminhar
                    </Button>
                  </div>
                </div>
              )}

              {/* Indicador de encaminhado */}
              {notification.forwarded && (
                <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                  <Forward className="h-3 w-3" />
                  <span>Encaminhado para a gerência</span>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
